Cache in ETS, persist in Postgres, coordinate with Redis (locks, rate limits, ephemeral sets) when useful. Use Mnesia for small catalogs or coordination within an Erlang cluster.
