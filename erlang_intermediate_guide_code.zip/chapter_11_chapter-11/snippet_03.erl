If Postgres is down, return {error, unavailable} but keep the process alive (circuit breaker will help).
