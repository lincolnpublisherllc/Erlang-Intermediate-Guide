start_link(#{host := H, port := P, user := U, pass := Pw, db := DB}) ->
  Pid = spawn_link(fun() ->
    {ok, Conn} = epgsql:connect(H, U, Pw, [{database, DB}, {port, P}, {timeout, 5000}]),
    loop(#st{conn = Conn})
  end),
  {ok, Pid}.
