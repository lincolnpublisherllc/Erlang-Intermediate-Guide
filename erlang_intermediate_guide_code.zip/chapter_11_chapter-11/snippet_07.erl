query(Pid, Sql) -> rpc(Pid, {query, Sql}).
exec(Pid, {Sql, Params}) -> rpc(Pid, {exec, Sql, Params}).
with_tx(Pid, Fun) -> rpc(Pid, {with_tx, Fun}).
