%% Extracted from document — source marker: json_logger_h.erl
-module(json_logger_h).
-behaviour(logger_handler).
-export([log/2, filter_config/1, config/1]).
-define(NOW_MS, erlang:system_time(millisecond)).
