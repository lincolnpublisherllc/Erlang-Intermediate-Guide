{"ts":1698000000000,"level":"info","component":"pay_fsm",
 "request_id":"r-123","msg":"authorized","meta":{"payment_id":"p1"}}
{"ts":1698000000010,"level":"info","component":"metrics",
 "msg":"metric.count","name":"payments.capture.count","value":1,"tags":{"currency":"USD"}}
