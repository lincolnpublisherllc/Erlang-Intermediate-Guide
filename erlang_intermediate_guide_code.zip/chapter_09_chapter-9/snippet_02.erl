{profiles, [
  {test, [
     {deps, [{proper, "1.4.0"}]}
  ]}
]}.
