start(Host, Port) ->
    {ok, Sock} = gen_udp:open(0, [binary, {active,false}]),
    St = #st{sock=Sock, host=Host, port=Port},
    put(metrics_udp, St), ok.
