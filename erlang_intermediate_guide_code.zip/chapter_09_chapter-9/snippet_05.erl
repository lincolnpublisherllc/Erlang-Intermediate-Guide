log(#{level := Level, msg := {report, Report}, meta := Meta}, _Conf) ->
    Map = #{
      ts => ?NOW_MS,
      level => Level,
      component => maps:get(component, Meta, undefined),
      request_id => maps:get(request_id, Meta, undefined),
      msg => maps:get(msg, Report, maps:get(gl, Report, <<"">>)),
      meta => Meta
    },
    Bin = jiffy:encode(Map),
    io:put_chars(Bin), io:nl();
log(#{level := Level, msg := {string, Str}, meta := Meta}, _Conf) ->
    Map = #{ts=>?NOW_MS, level=>Level, component=>maps:get(component,Meta,undefined),
            request_id=>maps:get(request_id,Meta,undefined), msg=>list_to_binary(Str), meta=>Meta},
    io:put_chars(jiffy:encode(Map)), io:nl();
log(_Other, _Conf) -> ok.
