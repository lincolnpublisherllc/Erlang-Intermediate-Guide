send(Io) ->
    #st{sock=Sock, host=H, port=P} = get(metrics_udp),
    gen_udp:send(Sock, H, P, iolist_to_binary(Io)).
