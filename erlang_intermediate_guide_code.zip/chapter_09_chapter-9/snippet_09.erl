%% payment captured
telemetry:execute(
  [payments, capture, complete],                 %% Event name
  #{amount => 100, duration_ms => 57},           %% Measurements
  #{payment_id => <<"p1">>, currency => <<"USD">>} %% Metadata
).
