%% metrics_udp.erl
gauge(Name, Val) ->
  send(io_lib:format("~s:~p|g", [Name, Val])).
