telemetry_handler(EventName, Measurements, Metadata, _Config) ->
    %% Fan out: counter + optional histogram export
    metrics_exporter(EventName, Measurements, Metadata, _Config),
    log_event(EventName, Measurements, Metadata),
    ok.
