tag_suffix(#{}) -> [];
tag_suffix(Map) ->
    %% StatsD tags extension: |#k:v,k2:v2
    Pairs = [io_lib:format("~s:~s",[K,V]) || {K,V} <- maps:to_list(Map)],
    ["|#", lists:join($,, Pairs)].
