incr(Name, Tags) ->
    logger:info(#{msg => <<"metric.count">>,
                  name => Name, value => 1, tags => Tags},
                #{component => metrics}).
timing(Name, Ms) ->
    logger:info(#{msg => <<"metric.timing">>,
                  name => Name, ms => Ms},
                #{component => metrics}).
