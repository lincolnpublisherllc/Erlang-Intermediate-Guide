%% Extracted from document — source marker: metrics_udp.erl
-module(metrics_udp).
-export([start/2, incr/2, timing/2]).
