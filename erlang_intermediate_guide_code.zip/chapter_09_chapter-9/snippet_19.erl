start(#{statsd := {Host,Port}}) ->
    metrics_udp:start(Host, Port),
    ok;
start(_)-> ok.
