%% rebar.config
{plugins, [
  %% Publish and fetch from hex.pm
  rebar3_hex,
  %% Formatting (optional, pick one; enforce in CI if you adopt it)
  rebar3_format
]}.
