inc(Name, Tags) ->
    metrics_udp:incr(Name, Tags),
    metrics_log:incr(Name, Tags),
    ok.
