config(Conf) -> Conf.
filter_config(Conf) -> Conf.
