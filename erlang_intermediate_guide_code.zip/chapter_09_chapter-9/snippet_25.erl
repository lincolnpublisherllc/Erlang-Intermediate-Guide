%% metrics.erl
gauge(Name, Val) ->
  metrics_udp:gauge(Name, Val),
  metrics_log:incr(Name, #{gauge => Val}), ok.
