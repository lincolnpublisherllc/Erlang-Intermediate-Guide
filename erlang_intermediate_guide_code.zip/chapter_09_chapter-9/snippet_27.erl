telemetry_handler([payments, authorize, error]=E, M, Meta, C) ->
  log_event(E,M,Meta),
  if rand:uniform(10) =:= 1 -> metrics:inc("payments.authorize.error", #{}); true -> ok end.
