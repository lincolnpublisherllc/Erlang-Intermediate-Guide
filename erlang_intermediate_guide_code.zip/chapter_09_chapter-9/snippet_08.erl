{deps, [
  {telemetry, "1.2.1"},  %% erlang-telemetry/telemetry
  {jiffy, "1.1.1"}       %% for the JSON logger above
]}.
