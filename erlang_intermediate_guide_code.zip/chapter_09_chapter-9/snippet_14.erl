incr(Name, Tags) ->
    send(io_lib:format("~s:1|c~s", [Name, tag_suffix(Tags)])).
