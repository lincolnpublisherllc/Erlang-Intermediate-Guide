{profiles, [
  {test, [
     {dialyzer, [
       {plt_file, "_build/test/dialyzer.plt"},
       {warnings, [no_return, unmatched_returns, error_handling]}
     ]}
  ]}
]}.
