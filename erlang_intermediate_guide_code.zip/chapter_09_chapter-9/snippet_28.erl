Drop this kit into your next service. You’ll get consistent metrics and logs across the codebase, and future you will thank present you when something breaks at 3 a.m.
