timing(Name, Ms) ->
    metrics_udp:timing(Name, Ms),
    metrics_log:timing(Name, Ms),
    ok.
