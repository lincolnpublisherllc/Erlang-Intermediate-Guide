timing(Name, Ms) ->
    send(io_lib:format("~s:~B|ms", [Name, Ms])).
