[
  {kernel, [
     {logger, [
        {handler, json, json_logger_h, #{}}
     ]}
  ]}
].
