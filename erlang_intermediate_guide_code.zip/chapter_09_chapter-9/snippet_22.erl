telemetry_handler(Event, M, Meta, _Cfg) ->
    case Event of
      [payments, capture, complete] ->
          metrics:inc("payments.capture.count", #{currency => maps:get(currency, Meta, <<"">>)}),
          metrics:timing("payments.capture.latency", maps:get(duration_ms, M, 0));
      [payments, authorize, error] ->
          metrics:inc("payments.authorize.error", #{reason => maps:get(reason, Meta, <<"unknown">>)});
      _ -> ok
    end.
