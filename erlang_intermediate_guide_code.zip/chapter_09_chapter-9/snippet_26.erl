Solution idea: Walk the map before logging; when key ∈ redaction list, replace the value.
