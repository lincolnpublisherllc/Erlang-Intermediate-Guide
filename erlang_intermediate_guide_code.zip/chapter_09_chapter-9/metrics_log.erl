%% Extracted from document — source marker: metrics_log.erl
-module(metrics_log).
-export([incr/2, timing/2]).
