%% Extracted from document — source marker: metrics.erl
-module(metrics).
-export([start/1, inc/2, timing/2]).
