telemetry:attach_many(
  pay_handlers,
  [
    {[payments, capture, complete], fun metrics_exporter/4, #{}},
    {[payments, authorize, error],  fun metrics_exporter/4, #{}}
  ],
  fun telemetry_handler/4,  %% we’ll define a wrapper that fans out
  #{}
).
