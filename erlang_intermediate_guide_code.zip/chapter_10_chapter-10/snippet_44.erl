rebar3 as prod release
_build/prod/rel/thumbsvc/bin/thumbsvc console
