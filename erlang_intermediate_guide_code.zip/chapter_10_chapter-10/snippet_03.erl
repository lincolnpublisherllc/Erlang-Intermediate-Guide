{aliases, [
  {check, ["compile", "as test ct"]},
  {ci,    ["as test dialyzer", "as test ct", "as prod release"]}
]}.
