Row: {Seq :: integer(), Job :: map()}
