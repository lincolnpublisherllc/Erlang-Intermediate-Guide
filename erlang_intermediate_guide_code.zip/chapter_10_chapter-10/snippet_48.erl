health(_C) ->
  {ok,200,_H,Body} = httpc:request(get, {"http://localhost:8080/healthz", []}, [], []),
  ?assert(string:find(binary_to_list(Body), "ok") > 0).
