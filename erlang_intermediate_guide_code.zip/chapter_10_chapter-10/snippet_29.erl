init(#{n := N, b := B}) ->
  Children = [ #{id => {job_worker, I},
                 start => {job_worker, start_link, [B]},
                 restart => permanent, shutdown => 5000,
                 type => worker, modules => [job_worker]}
               || I <- lists:seq(1, N) ],
  {ok, {{one_for_one, 5, 10}, Children}}.
