handle_call({enqueue, Job}, _From, S=#st{next=N, max=Max}) ->
  case ets:info(jobq, size) < Max of
    true ->
      ets:insert(jobq, {N, Job}),
      ets:insert(jobidx, {maps:get(id, Job), queued, #{seq => N}}),
      telemetry:execute([jobs, enqueued], #{count => 1}, #{id => maps:get(id, Job)}),
      {reply, {ok, N}, S#st{next=N+1}};
    false ->
      {reply, {error, busy}, S}
  end;
