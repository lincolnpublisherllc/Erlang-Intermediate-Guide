ok(Req, Map)  -> cowboy_req:reply(200, #{<<"content-type">> => <<"application/json">>},
                                  jiffy:encode(Map), Req).
err(Req, Map) -> cowboy_req:reply(400, #{<<"content-type">> => <<"application/json">>},
                                  jiffy:encode(Map), Req).
read(Req) ->
  {ok, Body, _} = cowboy_req:read_body(Req),
  jiffy:decode(Body, [return_maps]).
