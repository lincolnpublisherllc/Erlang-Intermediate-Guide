loop(Base) ->
  case job_queue_gs:reserve() of
    none ->
      timer:sleep(50), loop(Base);
    {ok, Job=#{id := Id, url := Url, width := W, height := H, attempt := A0}} ->
      T0 = erlang:monotonic_time(millisecond),
      case do_work(Url, W, H) of
        {ok, Meta} ->
          Dur = erlang:monotonic_time(millisecond) - T0,
          telemetry:execute([jobs, work, ok], #{duration_ms => Dur}, #{id => Id}),
          ok = job_queue_gs:complete(Id, Meta),
          loop(Base);
        {error, Why} ->
          Dur = erlang:monotonic_time(millisecond) - T0,
          telemetry:execute([jobs, work, error], #{duration_ms => Dur}, #{id => Id, reason => Why}),
          A = maps:get(attempt, Job, 0) + 1,
          Delay = retry:next(A, Base),
          Job1 = Job#{attempt => A, scheduled_at => erlang:system_time(millisecond)+Delay},
          requeue(Job1, Delay),
          loop(Base)
      end
  end.
