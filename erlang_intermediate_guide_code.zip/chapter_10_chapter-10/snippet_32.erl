%% apps/core/src/json.erl
-module(json).
-export([ok/2, err/2, read/1]).
