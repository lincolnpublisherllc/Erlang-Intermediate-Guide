10.6.3 Pool supervisor
%% apps/worker/src/worker_pool_sup.erl
-module(worker_pool_sup).
-behaviour(supervisor).
-export([start_link/1, init/1]).
