start_link(BaseBackoff) ->
  spawn_link(?MODULE, loop, [BaseBackoff]).
