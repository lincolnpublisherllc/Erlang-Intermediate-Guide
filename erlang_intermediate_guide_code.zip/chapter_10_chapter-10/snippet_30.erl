%% apps/api/src/api_router.erl
-module(api_router).
-export([start_link/1, stop/0]).
start_link(Port) ->
  Dispatch = cowboy_router:compile([
    {'_', [
      {"/healthz",   api_h_health, []},
      {"/readyz",    api_h_ready,  []},
      {"/jobs",      api_h_jobs,   []},
      {"/jobs/:id",  api_h_job,    []}
    ]}
  ]),
  {ok, _} = cowboy:start_clear(http, [{port, Port}], #{env => #{dispatch => Dispatch}}).
