Backpressure: queue max set; return {error, busy} when full.
Timeouts: add timeouts on HTTP clients if/when real work does I/O.
