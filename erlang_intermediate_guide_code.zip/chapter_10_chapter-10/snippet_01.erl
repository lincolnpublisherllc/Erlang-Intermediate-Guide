apps/
  api/          % Cowboy HTTP adapter + routing + validation
  core/         % pure helpers: validation, id gen, retry calc, encode
  queue/        % ETS-backed queue + persistence API
  worker/       % worker pool (pull model) + business logic stub
  obs/          % telemetry + json logger handler (from ch. 9)
config/
  sys.config{,.dev,.test,.prod}
  vm.args
rebar.config
