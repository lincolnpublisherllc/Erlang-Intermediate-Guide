init(Children) ->
  {ok, {{one_for_one, 5, 10}, Children}}.
