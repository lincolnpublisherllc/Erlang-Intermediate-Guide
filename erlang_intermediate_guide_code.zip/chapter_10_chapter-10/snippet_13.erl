stats() ->
  gen_server:call(?MODULE, stats).
