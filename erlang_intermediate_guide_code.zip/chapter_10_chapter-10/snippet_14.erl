init(Opts) ->
  process_flag(trap_exit, true),
  Max = maps:get(max, Opts, 10000),
  ets:new(jobq,   [named_table, ordered_set, public]),
  ets:new(jobidx, [named_table, set, public]),
  {ok, #st{max=Max}}.
