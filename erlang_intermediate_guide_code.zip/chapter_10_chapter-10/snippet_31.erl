stop() -> ranch:stop_listener(http).
