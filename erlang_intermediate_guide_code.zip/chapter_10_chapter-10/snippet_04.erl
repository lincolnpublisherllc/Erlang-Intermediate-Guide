app_sup
 ├─ obs_sup                 (attach telemetry handlers, json logger)
 ├─ queue_sup               (ets owner + queue server)
 ├─ worker_pool_sup         (N workers; pull jobs)
 └─ api_sup                 (Cowboy endpoint)
