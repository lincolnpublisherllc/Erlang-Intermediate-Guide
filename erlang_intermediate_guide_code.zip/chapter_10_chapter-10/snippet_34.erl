%% apps/core/src/validate.erl
-module(validate).
-export([job/1]).
