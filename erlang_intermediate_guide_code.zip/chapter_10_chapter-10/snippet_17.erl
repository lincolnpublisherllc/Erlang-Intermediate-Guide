handle_call({complete, Id, Result}, _From, S) ->
  ets:insert(jobidx, {Id, done, #{result => Result}}),
  telemetry:execute([jobs, complete], #{count => 1}, #{id => Id}),
  {reply, ok, S};
