{deps, [
  {cowboy, "2.10.0"},
  {telemetry, "1.2.1"},
  {jiffy, "1.1.1"},
  {recon, "2.5.3"}
]}.
