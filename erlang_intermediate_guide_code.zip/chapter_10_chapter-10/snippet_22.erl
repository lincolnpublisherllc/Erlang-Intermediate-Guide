%% apps/worker/src/job_worker.erl
-module(job_worker).
-export([start_link/1, loop/1]).
