Solution sketch: store {Id -> Seq} in jobidx meta; on delete, ets:delete(jobq, Seq) and set status canceled.
