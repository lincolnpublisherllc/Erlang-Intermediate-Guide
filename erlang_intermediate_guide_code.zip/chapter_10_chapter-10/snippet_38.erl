start(_Type, _Args) ->
  logger:set_metadata(#{component => service}),
  Children = [
    %% observability init (telemetry handlers)
    #{id => obs_sup, start => {obs_sup, start_link, []}, type => supervisor},
    %% queue
    #{id => queue, start => {job_queue_gs, start_link, [#{max => 20000}]}, type => worker},
    %% workers
    #{id => worker_pool, start => {worker_pool_sup, start_link, [#{size => 8, base_backoff => 200}]}, type => supervisor},
    %% api
    #{id => api, start => {api_router, start_link, [8080]}, type => worker}
  ],
  {ok, Sup} = supervisor:start_link({local, ?MODULE}, ?MODULE, Children),
  {ok, Sup}.
