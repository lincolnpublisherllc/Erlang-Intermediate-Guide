handle_call({fail, Id, Reason}, _From, S) ->
  ets:insert(jobidx, {Id, failed, #{reason => Reason}}),
  telemetry:execute([jobs, failed], #{count => 1}, #{id => Id}),
  {reply, ok, S};
