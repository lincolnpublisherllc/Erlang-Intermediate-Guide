Health: fail readiness when workers = 0 or queue len > threshold for N seconds.
