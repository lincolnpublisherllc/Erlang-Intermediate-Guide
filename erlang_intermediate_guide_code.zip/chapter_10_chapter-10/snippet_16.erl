handle_call(reserve, _From, S) ->
  case ets:first(jobq) of
    '$end_of_table' -> {reply, none, S};
    K ->
      [{_K, Job}] = ets:lookup(jobq, K),
      ets:delete(jobq, K),
      Id = maps:get(id, Job),
      ets:insert(jobidx, {Id, in_progress, #{reserved_at => erlang:system_time(millisecond)}}),
      {reply, {ok, Job}, S}
  end;
