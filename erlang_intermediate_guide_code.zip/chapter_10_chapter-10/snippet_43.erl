{relx, [
  {release, {thumbsvc, "0.1.0"}, [kernel, stdlib, sasl, crypto, ranch, cowboy, thumbsvc]},
  {dev_mode, false},
  {include_erts, true},
  {sys_config, "config/sys.config.prod"},
  {vm_args, "config/vm.args"}
]}.
