all() -> [health, job_lifecycle].
