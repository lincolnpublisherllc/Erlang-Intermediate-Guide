complete(Id, Result) ->
  gen_server:call(?MODULE, {complete, Id, Result}).
