init_per_suite(C) ->
  application:ensure_all_started(thumbsvc), C.
end_per_suite(_C) ->
  application:stop(thumbsvc), ok.
