%% apps/api/src/app_sup.erl (or apps/service/src/service_sup.erl)
-module(app_sup).
-behaviour(application).
-export([start/2, stop/1]).
