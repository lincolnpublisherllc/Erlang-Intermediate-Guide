#!/usr/bin/env escript
-mode(compile).
main([NStr]) ->
  inets:start(),
  N = list_to_integer(NStr),
  URL = "http://localhost:8080/jobs",
  Payload = jiffy:encode(#{url => <<"http://ex/img.jpg">>, width => 100, height => 80}),
  T0 = erlang:monotonic_time(millisecond),
  [spawn(fun() -> httpc:request(post, {URL, [], "application/json", Payload}, [], []) end)
   || _ <- lists:seq(1,N)],
  timer:sleep(1000),
  T1 = erlang:monotonic_time(millisecond),
  io:format("Submitted ~p in ~p ms~n", [N, T1-T0]).
