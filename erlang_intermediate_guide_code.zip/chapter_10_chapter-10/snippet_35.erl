job(#{<<"url">> := U, <<"width">> := W, <<"height">> := H}) when
      is_binary(U), is_integer(W), W>0, is_integer(H), H>0 ->
  {ok, #{url => U, width => W, height => H}};
job(_) -> {error, bad_input}.
