job_lifecycle(_C) ->
  Body = jiffy:encode(#{url => <<"http://ex/1.jpg">>, width => 100, height => 80}),
  {ok,200,_,Resp} = httpc:request(post, {"http://localhost:8080/jobs", [], "application/json", Body}, [], []),
  #{<<"id">> := Id} = jiffy:decode(Resp, [return_maps]),
  timer:sleep(200),
  {ok,Code,_,B2} = httpc:request(get, {lists:flatten(io_lib:format("http://localhost:8080/jobs/~s",[Id])), []}, [], []),
  ?assert(lists:member(Code, [200,404])),
  ok.
