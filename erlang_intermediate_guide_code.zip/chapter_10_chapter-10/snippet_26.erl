%% Stub work: “download + resize”. Replace with real code later.
do_work(_Url, _W, _H) ->
  %% simulate flaky external call
  case rand:uniform(5) of
    1 -> {error, transient};
    _ -> {ok, #{mime => <<"image/jpeg">>, bytes => 12345}}
  end.
