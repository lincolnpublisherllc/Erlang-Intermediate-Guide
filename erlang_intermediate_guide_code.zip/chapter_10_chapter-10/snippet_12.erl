fail(Id, Reason) ->
  gen_server:call(?MODULE, {fail, Id, Reason}).
