handle_call(stats, _From, S) ->
  {reply, #{qsize => ets:info(jobq, size)}, S};
