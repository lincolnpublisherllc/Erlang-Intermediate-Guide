%% apps/queue/src/job_queue_gs.erl
-module(job_queue_gs).
-behaviour(gen_server).
-export([start_link/1, enqueue/1, reserve/0, complete/2, fail/2, stats/0]).
-export([init/1, handle_call/3, handle_info/2, handle_cast/2, terminate/2, code_change/3]).
