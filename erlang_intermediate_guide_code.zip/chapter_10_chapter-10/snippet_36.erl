%% apps/api/src/api_h_jobs.erl
-module(api_h_jobs).
-export([init/2]).
init(Req, _State) ->
  case json:read(Req) of
    Map ->
      case validate:job(Map) of
        {ok, Clean} ->
          Id = <<(erlang:unique_integer([positive])):64/integer>>,
          Job = Clean#{id => Id, attempt => 0},
          case job_queue_gs:enqueue(Job) of
            {ok, _Seq} ->
              telemetry:execute([http, jobs, create], #{count=>1}, #{id=>Id}),
              json:ok(Req, #{id => Id, status => <<"queued">>});
            {error, busy} ->
              json:err(Req, #{error => <<"busy">>})
          end;
        {error, _} ->
          json:err(Req, #{error => <<"bad_input">>})
      end
  end.
%% apps/api/src/api_h_job.erl
-module(api_h_job).
-export([init/2]).
init(Req0, _Opts) ->
  {Id, Req} = cowboy_req:binding(id, Req0),
  case ets:lookup(jobidx, Id) of
    [{_Id, Status, Meta}] ->
      json:ok(Req, #{id => Id, status => atom_to_binary(Status, utf8), meta => Meta});
    [] ->
      cowboy_req:reply(404, #{}, <<"not found">>, Req)
  end.
%% apps/api/src/api_h_health.erl
-module(api_h_health).
-export([init/2]).
init(Req, _) ->
  json:ok(Req, #{ok => true}).
%% apps/api/src/api_h_ready.erl
-module(api_h_ready).
-export([init/2]).
init(Req, _) ->
  #{qsize := Q} = job_queue_gs:stats(),
  json:ok(Req, #{ready => true, queue => Q}).
