%% apps/core/src/retry.erl
-module(retry).
-export([next/2]).
-spec next(non_neg_integer(), non_neg_integer()) -> non_neg_integer().
next(Attempt, Base) ->
  Cap = 10_000,
  Core = erlang:min(Cap, Base bsl Attempt),
  Core + (rand:uniform(Base) - 1).
