-spec add([user()], user_in()) -> {ok, [user()]} | {error, bad_user}.
add(List, #{name := Name, role := Role})
        when is_list(Name), Name =/= "", is_atom(Role) ->
    Id  = next_id(List),
    New = #{id => Id, name => Name, role => Role},
    {ok, [New | List]};
add(_List, _Else) ->
    {error, bad_user}.
