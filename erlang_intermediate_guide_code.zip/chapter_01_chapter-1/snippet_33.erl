-spec only_even_int(number()) -> {ok, integer()} | {error, bad}.
only_even_int(N) when is_integer(N), N rem 2 =:= 0 -> {ok, N};
only_even_int(_) -> {error, bad}.
