%% {add, A, B} | {mul, A, B}
Accept only integers. Return {ok, Int} or {error, Reason}.
