messy(true, X)  -> X;
messy(false, _) -> error.
