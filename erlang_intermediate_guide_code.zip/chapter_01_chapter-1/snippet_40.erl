A shell-to-module loop that keeps iteration quick without losing testability.
