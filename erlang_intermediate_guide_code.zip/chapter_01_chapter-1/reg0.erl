%% Extracted from document — source marker: reg0.erl
-module(reg0).
-export([add/2, find/2]).
