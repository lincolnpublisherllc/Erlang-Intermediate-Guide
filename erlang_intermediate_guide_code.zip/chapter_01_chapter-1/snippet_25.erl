-spec next_id([user()]) -> pos_integer().
next_id([]) -> 1;
next_id(L)  -> lists:max([Id || #{id := Id} <- L]) + 1.
