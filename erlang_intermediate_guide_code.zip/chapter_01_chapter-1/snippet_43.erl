Keep float inputs returning {error, bad_number}. Do not coerce.
