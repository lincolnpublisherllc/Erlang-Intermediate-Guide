add(List, #{name := string(), role := atom()}) -> {ok, NewList}
find(List, Name :: string()) -> {ok, Map} | {error, not_found}
