find(List, Name) ->
    case lists:filter(fun(M) -> maps:get(name, M, undefined) =:= Name end, List) of
        [M|_] -> M;
        []    -> not_found
    end.
