handle({add, A, B}) when is_integer(A), is_integer(B) -> {ok, A + B};
