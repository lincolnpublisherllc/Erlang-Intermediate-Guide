%% Accepts {ok, Int} only. Rejects floats pretending to be ints.
limit({ok, N}) when is_integer(N), N >= 0, N =< 1000 -> {ok, N};
limit({ok, _Other}) -> {error, bad_limit};
limit(_Else)        -> {error, missing}.
If you used == in a guard, {ok, 10.0} could sneak through as a limit. Stick to exact typing.
