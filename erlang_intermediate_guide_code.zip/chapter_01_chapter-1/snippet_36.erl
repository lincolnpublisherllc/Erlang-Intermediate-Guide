Write to_name/1 that accepts binaries or list strings and returns {ok, String} where String is a list. Reject empty after trim.
