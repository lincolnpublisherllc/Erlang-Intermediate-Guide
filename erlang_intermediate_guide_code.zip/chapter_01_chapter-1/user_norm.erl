%% Extracted from document — source marker: user_norm.erl
-module(user_norm).
-export([normalize/1]).
