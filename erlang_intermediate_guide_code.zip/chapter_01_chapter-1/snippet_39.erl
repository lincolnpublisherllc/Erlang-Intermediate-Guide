-spec tidy(boolean(), term()) -> {ok, term()} | {error, denied}.
tidy(true,  X) -> {ok, X};
tidy(false, _) -> {error, denied}.
