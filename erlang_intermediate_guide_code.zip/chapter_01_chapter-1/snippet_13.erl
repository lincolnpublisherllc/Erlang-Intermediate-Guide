1> X = 5.
5
1> X = 6.
** exception error: no match of right hand side value 6
