Write only_even_int/1 that returns {ok, N} only when the input is exactly an even integer. Floats like 2.0 must be rejected.
