%% Safe probe
1> maps:is_key(id, #{name => "Ada"}).
false
Choose explicit failure when missing keys are bugs. Use maps:get/3 with defaults when optional.
