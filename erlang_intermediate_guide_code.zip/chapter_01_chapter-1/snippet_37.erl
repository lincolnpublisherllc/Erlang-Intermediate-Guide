-spec to_name(term()) -> {ok, string()} | {error, bad_name}.
to_name(<<_/binary>> = B) ->
    Str = string:trim(binary_to_list(B)),
    case Str of "" -> {error, bad_name}; _ -> {ok, Str} end;
to_name(S) when is_list(S) ->
    Str = string:trim(S),
    case Str of "" -> {error, bad_name}; _ -> {ok, Str} end;
to_name(_) ->
    {error, bad_name}.
