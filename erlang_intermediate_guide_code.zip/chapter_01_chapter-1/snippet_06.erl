normalize(#{name := N, age := A}) when is_list(N), is_integer(A), A >= 0 ->
    {ok, #{name => N, age => A}};
normalize(#{name := _}) ->
    {error, missing_age};
normalize(#{age := _}) ->
    {error, missing_name};
normalize(_Else) ->
    {error, bad_input}.
