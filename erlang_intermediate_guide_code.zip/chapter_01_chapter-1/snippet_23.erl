-spec find([user()], string()) -> {ok, user()} | {error, not_found}.
find(List, Name) when is_list(Name), Name =/= "" ->
    case [U || U = #{name := N} <- List, N =:= Name] of
        [Hit | _] -> {ok, Hit};
        []        -> {error, not_found}
    end.
