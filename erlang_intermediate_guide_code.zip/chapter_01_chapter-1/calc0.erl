%% Extracted from document — source marker: calc0.erl
-module(calc0).
-export([handle/2]).
%% handle(Op, Args)
handle("add", [A,B]) -> A + B;
handle("mul", [A,B]) -> A * B;
handle(_, _)         -> error.
