%% Anti-pattern: deep if/case ladder
normalize_user(User) ->
  case User of
    #{name := N, age := A} when is_list(N), is_integer(A), A >= 0 -> #{name => N, age => A};
    _ -> {error, bad_input}
  end.
