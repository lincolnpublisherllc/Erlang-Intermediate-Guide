%% Extracted from document — source marker: math_safe.erl
-module(math_safe).
-export([avg/1]).
