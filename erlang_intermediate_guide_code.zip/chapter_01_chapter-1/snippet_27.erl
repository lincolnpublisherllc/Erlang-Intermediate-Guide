{profiles, [
  {dev, [
    {dialyzer, [
       {warnings, [no_return, unmatched_returns, error_handling]},
       {plt_apps, [kernel, stdlib, erts, compiler, syntax_tools]}
    ]}
  ]}
]}.
