%% Smoke tests (quick sanity)
add_find_test_() ->
  {setup,
   fun() -> [] end,
   fun(_)-> ok end,
   [
     fun() ->
       {ok, L1} = add([], #{name => "Ada", role => admin}),
       {ok, U}  = find(L1, "Ada"),
       ?_assertMatch(#{id := _, name := "Ada", role := admin}, U)
     end
   ]}.
