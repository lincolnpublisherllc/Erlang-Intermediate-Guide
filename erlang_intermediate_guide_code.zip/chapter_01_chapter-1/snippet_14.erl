1> X =:= 5.
true
