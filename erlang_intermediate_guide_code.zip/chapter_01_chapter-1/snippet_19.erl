#{id => pos_integer(), name => string(), role => atom()}
