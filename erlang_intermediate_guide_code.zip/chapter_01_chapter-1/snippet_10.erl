erl -pa _build/dev/lib/myapp/ebin
