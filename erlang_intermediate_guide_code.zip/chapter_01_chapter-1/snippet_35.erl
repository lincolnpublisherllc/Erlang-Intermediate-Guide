-spec take_id(map()) -> {ok, integer()} | {error, bad_id}.
take_id(#{id := I}) when is_integer(I) -> {ok, I};
take_id(_) -> {error, bad_id}.
