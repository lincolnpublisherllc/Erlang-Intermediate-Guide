erl -pa _build/dev/lib/yourapp/ebin
1> c(reg1).
{ok,reg1}
2> reg1:add([], #{name => "Ada", role => admin}).
{ok,[#{id => 1,name => "Ada",role => admin}]}
3> reg1:add([], #{name => "", role => user}).
{error,bad_user}
