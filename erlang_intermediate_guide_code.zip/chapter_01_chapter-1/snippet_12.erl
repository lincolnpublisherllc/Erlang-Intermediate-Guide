-spec avg([number()]) -> {ok, float()} | {error, empty}.
avg([])    -> {error, empty};
avg([H|T]) ->
    Sum = lists:foldl(fun erlang:'+'/2, H, T),
    Len = 1 + length(T),
    {ok, Sum / Len}.
