c(my_module).  %% reads my_module.erl in current dir
