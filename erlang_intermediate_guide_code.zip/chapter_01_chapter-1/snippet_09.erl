send_if_ready(M) when compute_heavy(M) -> ...   %% heavy work in guard
