reg1:add/2 returns {error, bad_user}. Clients must handle the tag, which is better behavior for a service boundary.
