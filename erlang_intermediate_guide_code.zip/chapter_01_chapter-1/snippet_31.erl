Node.js: No pattern matching. You emulate with schema validators and switch blocks. Consider this when designing boundaries with other services.
