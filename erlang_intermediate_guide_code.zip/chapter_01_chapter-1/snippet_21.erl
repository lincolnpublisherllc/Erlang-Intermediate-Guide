%% Types (for readers and Dialyzer)
-type user() :: #{id := pos_integer(), name := string(), role := atom()}.
-type user_in() :: #{name := string(), role := atom()}.
