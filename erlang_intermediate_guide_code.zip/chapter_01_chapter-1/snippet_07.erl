case user_norm:normalize(Map) of
  {ok, Clean}             -> persist(Clean);
  {error, missing_age}    -> warn("Need age");
  {error, missing_name}   -> warn("Need name");
  {error, bad_input}      -> ignore
end.
