Use == and /= only when you explicitly accept numeric coercion.
