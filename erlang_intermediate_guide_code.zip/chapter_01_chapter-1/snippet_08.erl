send_if_ready(#{status := ready, count := C}) when is_integer(C), C > 0 ->
    do_send(C);
send_if_ready(_Else) ->
    {error, not_ready}.
