%% Extracted from document — source marker: query_guard.erl
-module(query_guard).
-export([limit/1]).
