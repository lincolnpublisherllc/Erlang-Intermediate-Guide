Implement take_id/1 that extracts an integer id from #{id := Int} and returns {ok, Int}. If id is missing or not an integer, return {error, bad_id}.
