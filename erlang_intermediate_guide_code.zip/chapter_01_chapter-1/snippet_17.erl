add(List, Map) ->
    if
        is_map(Map) andalso maps:is_key(name, Map) ->
            [Map | List];
        true -> List
    end.
