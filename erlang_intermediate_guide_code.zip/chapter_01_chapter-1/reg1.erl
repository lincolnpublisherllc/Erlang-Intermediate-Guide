%% Extracted from document — source marker: reg1.erl
-module(reg1).
-export([add/2, find/2]).
-include_lib("eunit/include/eunit.hrl").
