backoff(Fun, BaseMs, Tries) ->
    case Fun() of
        {ok, Status, _Hs, Ref} when Status >= 200, Status < 300 ->
            _ = hackney:skip_body(Ref),
            ok;
        {ok, _Status, _Hs, Ref} ->
            _ = hackney:skip_body(Ref),
            retry(Fun, BaseMs, Tries-1);
        {error, _}=E ->
            retry(fun() -> Fun() end, BaseMs, Tries-1, E)
    end.
