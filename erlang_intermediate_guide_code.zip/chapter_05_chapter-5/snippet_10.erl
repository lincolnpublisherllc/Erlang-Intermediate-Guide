-spec split(binary()) -> [binary()].
split(Line) ->
    split(Line, [], <<>>, outside).
