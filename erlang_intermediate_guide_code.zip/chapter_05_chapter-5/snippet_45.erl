For network ingestion (TCP), active sockets can push data into your mailbox. Add selective receive and flow control carefully, or use {active, once} to re-enable after each packet.
