5.8 Active vs passive file modes: when and why
Passive (what we used): you decide when to read. Simple, explicit backpressure.
