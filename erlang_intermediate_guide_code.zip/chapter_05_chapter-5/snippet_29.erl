start_link(Url, Opts) ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, {Url, Opts}, []).
