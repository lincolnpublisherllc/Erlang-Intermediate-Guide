loop(FD, Chunk, Acc, Carry) ->
    case file:read(FD, Chunk) of
        eof ->
            Acc1 = if Carry =:= <<>> -> Acc; true -> Acc + 1 end,
            {ok, Acc1};
        {ok, Bin} ->
            {Lines, C} = line_split(<<Carry/binary, Bin/binary>>),
            loop(FD, Chunk, Acc + length(Lines), C)
    end.
