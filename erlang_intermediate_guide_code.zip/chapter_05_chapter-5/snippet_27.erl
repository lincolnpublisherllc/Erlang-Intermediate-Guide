%% For demo: convert a line to #{line => <<...>>, ts => Now}
to_event(LineBin) ->
    #{line => LineBin, ts => erlang:system_time(millisecond)}.
