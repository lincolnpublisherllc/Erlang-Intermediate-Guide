loop() ->
    receive
        {log_line, Bin} ->
            Event = log_parse:to_event(Bin),
            ok = log_shipper:push(Event),
            loop();
        stop -> ok
    end.
