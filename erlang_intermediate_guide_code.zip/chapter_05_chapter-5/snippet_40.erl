start(Path, Url) ->
    application:ensure_all_started(hackney),
    {ok, _R} = log_reader:start_link(Path, 64*1024),
    {ok, _S} = log_shipper:start_link(Url, [{max, 500}, {interval, 2000}]),
    ok = log_reader:subscribe(self()),
    loop().
