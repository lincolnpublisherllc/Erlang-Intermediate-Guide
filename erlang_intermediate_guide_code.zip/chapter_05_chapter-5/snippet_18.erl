{deps, [
  {hackney, "1.20.1"},
  {jiffy, "1.1.1"}
]}.
