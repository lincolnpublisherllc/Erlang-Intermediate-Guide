handle_call({subscribe, P}, _From, S=#st{subs=Subs}) ->
    {reply, ok, S#st{subs = lists:usort([P|Subs])}};
handle_call(_,_,S) -> {reply, {error,bad_call}, S}.
