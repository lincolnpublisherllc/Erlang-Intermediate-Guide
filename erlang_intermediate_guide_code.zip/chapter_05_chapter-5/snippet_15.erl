5.5 Iolists: write without concatenating
