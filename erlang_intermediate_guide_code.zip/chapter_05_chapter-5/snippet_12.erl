to_map(Headers, LineBin) ->
    Fields = csv_small:split(LineBin),
    Pairs = lists:zip(Headers, Fields),
    maps:from_list(Pairs).
