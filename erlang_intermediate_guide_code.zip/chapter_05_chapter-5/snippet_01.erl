{ok, FD} = file:open("access.log", [read, raw, binary]).
