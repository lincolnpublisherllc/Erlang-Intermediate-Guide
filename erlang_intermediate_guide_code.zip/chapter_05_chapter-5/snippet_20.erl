start_link(Path, Chunk) ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, {Path, Chunk}, []).
