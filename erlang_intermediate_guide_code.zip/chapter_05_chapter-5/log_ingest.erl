%% Extracted from document — source marker: log_ingest.erl
-module(log_ingest).
-export([start/2, stop/0]).
