handle_cast(_, S) -> {noreply, S}.
terminate(_, #st{fd=FD}) -> catch file:close(FD), ok.
code_change(_,S,_) -> {ok,S}.
