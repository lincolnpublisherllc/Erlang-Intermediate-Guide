1> log_ingest:start("access.log", "http://localhost:8080/ingest").
