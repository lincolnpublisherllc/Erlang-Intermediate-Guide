gun: HTTP/1.1 and HTTP/2 over persistent connections; great when you need many requests and backpressure control.
