handle_info(flush, S) ->
    S1 = do_flush(S),
    TRef = erlang:send_after(S1#st.interval, self(), flush),
    {noreply, S1#st{timer=TRef}};
handle_info(_Info, S) -> {noreply, S}.
