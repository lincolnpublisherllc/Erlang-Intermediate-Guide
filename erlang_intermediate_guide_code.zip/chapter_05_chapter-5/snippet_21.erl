subscribe(Pid) ->
    gen_server:call(?MODULE, {subscribe, Pid}).
