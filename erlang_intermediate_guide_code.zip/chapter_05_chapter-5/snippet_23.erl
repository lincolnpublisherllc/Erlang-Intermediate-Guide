handle_info(tick, S=#st{fd=FD, chunk=Sz, carry=Carry, subs=Subs}) ->
    case file:read(FD, Sz) of
        eof ->
            erlang:send_after(200, self(), tick),
            {noreply, S};
        {ok, Bin} ->
            {Lines, NewCarry} = line_split(<<Carry/binary, Bin/binary>>),
            [Sub ! {log_line, L} || Sub <- Subs, L <- Lines],
            erlang:send_after(1, self(), tick),
            {noreply, S#st{carry=NewCarry}};
        {error, _} ->
            erlang:send_after(500, self(), tick),
            {noreply, S}
    end;
handle_info(_Other, S) -> {noreply, S}.
