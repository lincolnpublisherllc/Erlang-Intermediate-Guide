%% Extracted from document — source marker: line_stream.erl
-module(line_stream).
-export([from_fd/2]).
