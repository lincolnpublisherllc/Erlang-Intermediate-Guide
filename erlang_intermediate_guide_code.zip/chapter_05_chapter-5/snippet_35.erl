do_flush(S=#st{acc=[]}) -> S;
do_flush(S=#st{acc=Acc, url=Url}) ->
    %% reverse to preserve arrival order
    Payload = encode_batch(lists:reverse(Acc)),
    case post_json(Url, Payload) of
        ok -> S#st{acc=[]};
        {error, _} ->
            %% keep acc to retry on next flush (simple strategy)
            S
    end.
