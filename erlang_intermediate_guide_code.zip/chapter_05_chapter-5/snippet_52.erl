intersperse([], _) -> [];
intersperse([X], _) -> [X];
intersperse([X|Xs], Sep) -> [X, Sep | intersperse(Xs, Sep)].
