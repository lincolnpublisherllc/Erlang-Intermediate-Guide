%% from_fd(FD, Chunk) -> fun(Acc0, FunPerLine) -> AccN
from_fd(FD, ChunkSz) ->
    fun(Acc0, FunPerLine) ->
        loop(FD, ChunkSz, <<>>, Acc0, FunPerLine)
    end.
