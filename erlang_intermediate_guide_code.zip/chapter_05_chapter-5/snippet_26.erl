line_split(Bin) ->
    Parts = binary:split(Bin, <<"\n">>, [global]),
    case Parts of
        [] -> {[], <<>>};
        [One] -> {[], One};
        Many ->
            {Ls, [Carry]} = lists:split(length(Many)-1, Many),
            { [strip_cr(L) || L <- Ls], Carry }
    end.
strip_cr(<<Rest/binary, "\r">>) -> Rest;
strip_cr(B) -> B.
