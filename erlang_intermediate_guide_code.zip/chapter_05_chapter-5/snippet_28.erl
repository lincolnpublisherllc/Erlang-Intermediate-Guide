-record(st, {
  url, max = 500, interval = 2000,
  timer = undefined, acc = []
}).
