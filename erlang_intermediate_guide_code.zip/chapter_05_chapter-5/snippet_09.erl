Fail soft when a line is malformed.
