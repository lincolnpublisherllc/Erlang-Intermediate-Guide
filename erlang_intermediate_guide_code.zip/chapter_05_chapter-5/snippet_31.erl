init({Url, Opts}) ->
    Max = proplists:get_value(max, Opts, 500),
    Interval = proplists:get_value(interval, Opts, 2000),
    TRef = erlang:send_after(Interval, self(), flush),
    {ok, #st{url=Url, max=Max, interval=Interval, timer=TRef}}.
