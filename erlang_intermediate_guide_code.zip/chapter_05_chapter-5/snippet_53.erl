gun persistent HTTP/1.1 connection that reuses the socket and applies backpressure (pause reads when the send queue is high)
