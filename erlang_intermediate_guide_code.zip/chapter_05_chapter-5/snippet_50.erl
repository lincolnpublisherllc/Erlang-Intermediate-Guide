next_delay(Base, Attempt) ->
    Core = min(10000, Base bsl Attempt),
    Core + rand:uniform(Base) - 1.
