read_chunks(FD, ChunkSz) ->
    case file:read(FD, ChunkSz) of
        eof        -> done;
        {ok, Bin}  -> handle_chunk(Bin), read_chunks(FD, ChunkSz);
        {error, E} -> {error, E}
    end.
