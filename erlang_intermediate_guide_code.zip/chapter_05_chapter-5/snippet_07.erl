strip_cr(<<Rest/binary, "\r">>) -> Rest;
strip_cr(Bin)                   -> Bin.
