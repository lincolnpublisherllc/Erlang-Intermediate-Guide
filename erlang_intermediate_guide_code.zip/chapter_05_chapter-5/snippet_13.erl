{ok, Obj} = jiffy:decode(<<"{\"user\":\"ada\"}">>, [return_maps]).
User = maps:get(<<"user">>, Obj).
