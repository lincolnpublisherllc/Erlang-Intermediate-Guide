%% Extracted from document — source marker: log_parse.erl
-module(log_parse).
-export([to_event/1]).
