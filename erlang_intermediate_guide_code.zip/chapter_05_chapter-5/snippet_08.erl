{ok, FD} = file:open("access.log", [read, raw, binary]),
Streamer = line_stream:from_fd(FD, 64*1024),
FunLine = fun(LineBin, Acc) -> [LineBin | Acc] end,
{ok, Lines} = Streamer([], FunLine),
ok = file:close(FD).
