handle_call(_,_,S)->{reply, {error,bad_call}, S}.
terminate(_,_) -> ok.
code_change(_,S,_) -> {ok,S}.
