init({Path, Chunk}) ->
    {ok, FD} = file:open(Path, [read, raw, binary]),
    ok = file:position(FD, eof),  %% start tailing new lines only
    erlang:send_after(200, self(), tick),
    {ok, #st{fd=FD, path=Path, chunk=Chunk}}.
