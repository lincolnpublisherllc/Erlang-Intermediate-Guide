retry(_Fun, _Base, 0, Err) -> Err;
retry(Fun, Base, N)        -> retry(Fun, Base, N, {error, retry_exhausted}).
retry(Fun, Base, N, Err) ->
    Jitter = rand:uniform(Base),
    timer:sleep(Base + Jitter),
    backoff(Fun, min(Base*2, 10_000), N).
