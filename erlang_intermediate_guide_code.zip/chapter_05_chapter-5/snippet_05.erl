loop(FD, ChunkSz, Carry, Acc, FunLine) ->
    case file:read(FD, ChunkSz) of
        eof ->
            %% Flush leftover without newline if non-empty
            Acc1 = if Carry =:= <<>> -> Acc; true -> FunLine(Carry, Acc) end,
            {ok, Acc1};
        {ok, Bin} ->
            {Lines, NewCarry} = split_lines(<<Carry/binary, Bin/binary>>),
            Acc1 = lists:foldl(fun(L, A) -> FunLine(L, A) end, Acc, Lines),
            loop(FD, ChunkSz, NewCarry, Acc1, FunLine);
        {error, E} ->
            {error, E}
    end.
