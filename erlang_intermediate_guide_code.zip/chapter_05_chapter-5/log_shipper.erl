%% Extracted from document — source marker: log_shipper.erl
-module(log_shipper).
-behaviour(gen_server).
-export([start_link/2, push/1]).
-export([init/1, handle_info/2, handle_call/3, handle_cast/2, terminate/2, code_change/3]).
