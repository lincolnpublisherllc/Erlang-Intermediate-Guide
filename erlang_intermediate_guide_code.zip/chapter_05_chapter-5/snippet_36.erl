encode_batch(Events) ->
    %% iolist-friendly JSON array
    %% Convert maps to jiffy terms first
    jiffy:encode(Events).
