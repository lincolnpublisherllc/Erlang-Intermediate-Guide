split_lines(Bin) ->
    %% Split on "\n" but keep last partial as carry
    Parts = binary:split(Bin, <<"\n">>, [global]),
    case Parts of
        []         -> {[], <<>>};
        [One]      -> {[], One};                       %% no newline yet
        Many       ->
            %% All except last are full lines, last is carry
            {Lines0, [Carry]} = lists:split(length(Many)-1, Many),
            %% Strip optional trailing \r for CRLF
            Lines = [strip_cr(L) || L <- Lines0],
            {Lines, Carry}
    end.
