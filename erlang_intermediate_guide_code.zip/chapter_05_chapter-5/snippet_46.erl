to_event(Line) ->
    [TsBin, LevelBin, MsgBin] = csv_small:split(Line),
    #{ts => TsBin, level => LevelBin, message => MsgBin}.
