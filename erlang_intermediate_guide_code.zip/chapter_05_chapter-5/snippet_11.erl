split(<<>>, Acc, Field, _State) ->
    lists:reverse([Field | Acc]);
split(<<$",Rest/binary>>, Acc, Field, outside) ->
    split(Rest, Acc, Field, inside);
split(<<$",$", Rest/binary>>, Acc, Field, inside) ->  % escaped quote ""
    split(Rest, Acc, <<Field/binary, $">>, inside);
split(<<$", Rest/binary>>, Acc, Field, inside) ->
    split(Rest, Acc, Field, outside);
split(<<$, , Rest/binary>>, Acc, Field, outside) ->
    split(Rest, [Field | Acc], <<>>, outside);
split(<<C, Rest/binary>>, Acc, Field, State) ->
    split(Rest, Acc, <<Field/binary, C>>, State).
