log_write(FD, Level, Msg) ->
    Ts = integer_to_binary(erlang:system_time(millisecond)),
    file:write(FD, [Ts, <<" ">>, Level, <<" ">>, Msg, <<"\n">>]).
