Bin = jiffy:encode(#{user => <<"ada">>, count => 3}).
