%% Extracted from document — source marker: csv_small.erl
-module(csv_small).
-export([split/1]).
