We’ll parse newline-delimited logs robustly even when a line is split across two chunks.
