Lines = [<<"{\"msg\":\"hi\"}\n">>, <<"{\"msg\":\"there\"}\n">>],
ok = file:write(FD, Lines).  %% zero-copy concat under the hood
