stop() -> self() ! stop, ok.
