handle_cast({event, E}, S=#st{acc=Acc, max=Max}) ->
    Acc1 = [E | Acc],
    case length(Acc1) >= Max of
        true  -> {noreply, do_flush(S#st{acc=Acc1})};
        false -> {noreply, S#st{acc=Acc1}}
    end;
handle_cast(_, S) -> {noreply, S}.
