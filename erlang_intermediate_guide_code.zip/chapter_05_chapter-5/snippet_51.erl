encode_array(Items) ->
    Sep = <<",">>,
    Bodies = intersperse([jiffy:encode(I) || I <- Items], Sep),
    [<<"[">>, Bodies, <<"]">>].
