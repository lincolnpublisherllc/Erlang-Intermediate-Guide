push(Event) ->
    gen_server:cast(?MODULE, {event, Event}).
