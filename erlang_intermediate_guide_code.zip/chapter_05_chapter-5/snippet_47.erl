count_lines(Path) ->
    {ok, FD} = file:open(Path, [read, raw, binary]),
    {ok, N} = loop(FD, 131072, 0, <<>>),
    file:close(FD),
    N.
