Actor thinking: one responsibility per process, explicit protocols, selective receive for control, and backpressure at the edges
