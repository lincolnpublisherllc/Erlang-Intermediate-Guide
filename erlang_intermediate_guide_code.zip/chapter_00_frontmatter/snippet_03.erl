If you’re brand new to Erlang, pause here and work through a beginner text first. If you’re comfortable with gen_server, pattern matching, lists and maps, you’re in the right place.
