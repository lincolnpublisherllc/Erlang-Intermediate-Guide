Each piece is simple on its own. Together they form a clean, observable system that is easy to extend.
