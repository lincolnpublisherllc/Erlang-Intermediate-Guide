Tagged tuples for replies: {ok, Value} or {error, Reason}
Exact equality in guards when it matters, to avoid silent coercions
