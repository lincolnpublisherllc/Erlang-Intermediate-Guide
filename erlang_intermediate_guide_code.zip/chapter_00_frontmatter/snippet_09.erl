Code focuses on clarity first. Micro-optimizations appear only when a profiler says they’re worth it.
