You can read in order or jump to what you need. The mid-sized project chapter ties it together and gives you a working base to extend.
