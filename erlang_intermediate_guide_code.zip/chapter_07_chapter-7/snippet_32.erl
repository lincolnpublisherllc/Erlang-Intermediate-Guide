How to design message protocols with correlation refs and selective receive.
