handle_call(stop, _From, S=#st{workers=Ws, q=Q}) ->
    %% Begin graceful shutdown: stop workers, refuse new jobs
    [W ! stop || W <- Ws],
    {reply, ok, S#st{shutting_down=true, idle=[], q=Q}};
handle_call({submit, Client, Fun0}, _From, S=#st{shutting_down=true}) ->
    {reply, {error, shutting_down}, S};
handle_call({submit, Client, Fun0}, _From, S=#st{idle=Idle, q=Q, max_q=Max}) ->
    Ref = make_ref(),
    case Idle of
      [W|Rest] ->
        W ! {do, Fun0, Ref, Client},
        {reply, {ok, Ref}, S#st{idle=Rest}};
      [] ->
        if queue:len(Q) < Max ->
             {reply, {ok, Ref}, S#st{q=queue:in({Ref, Client, Fun0}, Q)}};
           true ->
             {reply, {error, busy}, S}
        end
    end.
