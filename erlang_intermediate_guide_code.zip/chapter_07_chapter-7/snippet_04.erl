Bounded queue at the edge
The pool refuses or delays new work when full. Callers either block (wait until capacity) or get {error, busy}.
Push–pull (“demand”)
Workers ask for work when they are idle. The manager never deposits more than one job per worker. Mailboxes stay shallow.
