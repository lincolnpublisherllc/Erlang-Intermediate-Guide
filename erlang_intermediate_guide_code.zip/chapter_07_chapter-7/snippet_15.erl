%% Ready workers pull work; we either give them queued work or mark idle
handle_info({ready, W}, S=#st{q=Q, idle=Idle}) ->
    case queue:out(Q) of
      {empty, _} ->
        {noreply, S#st{idle=[W|Idle]}};
      {{value, {Ref, Client, Fun0}}, Q1} ->
        W ! {do, Fun0, Ref, Client},
        {noreply, S#st{q=Q1}}
    end;
