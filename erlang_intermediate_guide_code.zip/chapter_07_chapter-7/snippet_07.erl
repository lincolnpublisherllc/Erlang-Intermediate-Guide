loop() ->
    %% Signal availability to the manager
    pool_gs ! {ready, self()},
    receive
        stop ->
            ok;  % graceful exit
        {do, Fun, Ref, Client} when is_function(Fun, 0) ->
            %% CPU-bound work; wrap in try to avoid crashing the manager
            Reply =
              try Fun() of
                Val -> {ok, Ref, Val}
              catch
                Class:Reason:Stack -> {error, Ref, {Class, Reason, Stack}}
              end,
            Client ! Reply,
            loop()
    end.
