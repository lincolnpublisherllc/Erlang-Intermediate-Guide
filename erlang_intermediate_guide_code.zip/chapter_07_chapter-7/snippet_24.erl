If you already have pool_gs, map by submitting jobs and collecting replies by reference. This gives you one queue and central backpressure, useful when many callers share the same pool.
