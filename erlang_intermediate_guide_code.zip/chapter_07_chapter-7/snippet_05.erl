receive {do, Fun, Ref, Client}
