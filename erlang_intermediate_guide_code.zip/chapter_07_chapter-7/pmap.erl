%% Extracted from document — source marker: pmap.erl
-module(pmap).
-export([pmap/3]).
