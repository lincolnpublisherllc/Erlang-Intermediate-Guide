start_link() ->
    spawn_link(?MODULE, loop, []).
