Hint: include Idx in the job and collect {ok, Ref, {Idx, Val}}, then sort by Idx or insert into an array-like map.
