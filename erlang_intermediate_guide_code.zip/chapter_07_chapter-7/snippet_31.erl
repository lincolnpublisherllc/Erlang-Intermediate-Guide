Hint: track queued jobs in a dict Ref -> {Client, Fun}; add a cancel(Ref) call that removes it from the queue and replies {ok, canceled}.
