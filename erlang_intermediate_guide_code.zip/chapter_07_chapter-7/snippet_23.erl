gather(_F, L, _K, _Refs, Acc, I) when I > length(L) -> lists:reverse(Acc);
gather(F, L, K, Refs, Acc, I) ->
    receive
      {Pid, Ref, Val} ->
          %% Launch next if any remain
          NextIdx = I + K,
          Refs1 =
            case lists:nthtail(NextIdx-1, L) of
              [] -> Refs;
              [Next|_] ->
                [spawn_monitor(fun() ->
                   self() ! {self(), make_ref(), apply(F,[Next])}
                 end)|Refs]
            end,
          gather(F, L, K, Refs1, [Val|Acc], I+1);
      {'DOWN', _MRef, process, _Pid, _Reason} ->
          gather(F, L, K, Refs, Acc, I)
    end.
