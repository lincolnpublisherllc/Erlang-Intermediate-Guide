7.2 Selective receive that scales
Selective receive pulls a specific message shape out of the mailbox and leaves the rest.
receive
  {ok, Ref, Val} -> Val;           %% matches only this Ref
  {error, Ref, Why} -> {error, Why}
after 5000 -> timeout
end.
