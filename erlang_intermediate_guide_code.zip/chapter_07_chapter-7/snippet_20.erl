%% compute(Fun, Timeout) -> {ok, Val} | {error, busy} | timeout
compute(Fun, Timeout) ->
    case pool_gs:submit(self(), Fun) of
      {ok, Ref} ->
        receive
          {ok, Ref, Val}     -> {ok, Val};
          {error, Ref, Why}  -> {error, Why}
        after Timeout -> timeout
        end;
      {error, busy} = Busy -> Busy
    end.
