%% Extracted from document — source marker: pool_client.erl
-module(pool_client).
-export([compute/2]).
