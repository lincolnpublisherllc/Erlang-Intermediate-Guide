Mailboxes, selective receive, cheap isolation
