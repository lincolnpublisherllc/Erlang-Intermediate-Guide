Backpressure: the queue is bounded by max_q. Callers get {error, busy} when full and can retry later.
