-record(st, {
  idle = []            :: [pid()],
  q                    :: queue:queue({ref(), pid(), fun(() -> term())}),
  max_q = 1000         :: non_neg_integer(),
  workers = []         :: [pid()],
  shutting_down = false
}).
