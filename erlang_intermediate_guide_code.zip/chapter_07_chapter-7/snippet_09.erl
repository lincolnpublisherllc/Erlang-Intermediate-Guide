start_link(Size) when is_integer(Size), Size > 0 ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, Size, []).
