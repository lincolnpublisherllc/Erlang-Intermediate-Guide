You can extend pool_gs:stop/0 to wait for the queue to drain before replying, or add stop/1 with a timeout that returns {ok, drained} or {error, timeout}.
