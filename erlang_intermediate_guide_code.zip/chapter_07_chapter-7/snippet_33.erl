Practical patterns for pmap and when to use a shared pool.
