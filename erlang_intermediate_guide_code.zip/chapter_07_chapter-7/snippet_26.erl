Fail-fast: return {error, busy} immediately when full (what we implemented)
