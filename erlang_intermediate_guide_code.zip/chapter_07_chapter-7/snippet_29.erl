Keep a map Idx -> Val
