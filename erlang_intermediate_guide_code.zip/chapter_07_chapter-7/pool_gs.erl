%% Extracted from document — source marker: pool_gs.erl
-module(pool_gs).
-behaviour(gen_server).
-export([start_link/1, stop/0, submit/2]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
         terminate/2, code_change/3]).
