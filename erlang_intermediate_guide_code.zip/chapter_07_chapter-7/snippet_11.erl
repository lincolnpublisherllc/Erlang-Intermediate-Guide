%% API: submit returns either {ok, Ref} (will reply later) or {error, busy}
submit(ClientPid, Fun0) when is_function(Fun0, 0) ->
    gen_server:call(?MODULE, {submit, ClientPid, Fun0}).
