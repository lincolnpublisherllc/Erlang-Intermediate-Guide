stop() -> gen_server:call(?MODULE, stop).
