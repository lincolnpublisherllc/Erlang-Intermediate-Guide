%% pmap(F, List, Concurrency)
pmap(F, L, K) ->
    Self = self(),
    Refs = [spawn_monitor(fun() -> Self ! {self(), Ref = make_ref(), apply(F,[X])} end)
            || X <- lists:sublist(L, K)],
    gather(F, L, K, Refs, [], 1).
