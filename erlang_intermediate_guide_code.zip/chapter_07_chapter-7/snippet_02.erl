%% Request/Reply shape using a correlation Ref
Client = self(),
Ref = make_ref(),
Server ! {sum, Ref, Client, [1,2,3]},
receive
  {ok, Ref, N} -> io:format("Sum=~p~n", [N])
after 1000 ->
  timeout
end.
