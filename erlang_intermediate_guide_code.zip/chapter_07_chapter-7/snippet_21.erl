1> {ok, _} = pool_gs:start_link(4).
2> Fun = fun() -> lists:sum([I*I || I <- lists:seq(1,20000)]) end.
3> [pool_client:compute(Fun, 2000) || _ <- lists:seq(1,10)].
You should see {ok, _} results. If you hammer it with far more concurrent submissions than max_q, some calls will return {error, busy} quickly instead of piling up in mailboxes.
