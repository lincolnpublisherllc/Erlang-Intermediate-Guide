%% Extracted from document — source marker: pool_worker.erl
-module(pool_worker).
-export([start_link/0, loop/0]).
