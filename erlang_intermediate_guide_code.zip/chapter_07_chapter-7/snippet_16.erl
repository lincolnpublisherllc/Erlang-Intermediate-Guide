%% Clean up dead workers; spawn a replacement unless shutting down
handle_info({'EXIT', W, _Reason}, S=#st{workers=Ws, idle=Idle, shutting_down=SD}) ->
    Ws1 = lists:delete(W, Ws),
    Idle1 = lists:delete(W, Idle),
    Ws2 = case SD of
            true  -> Ws1;
            false -> [pool_worker:start_link() | Ws1]
          end,
    {noreply, S#st{workers=Ws2, idle=Idle1}};
