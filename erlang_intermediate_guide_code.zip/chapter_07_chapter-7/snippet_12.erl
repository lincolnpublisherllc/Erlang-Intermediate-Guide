init(Size) ->
    process_flag(trap_exit, true),
    Ws = [pool_worker:start_link() || _ <- lists:seq(1, Size)],
    {ok, #st{q=queue:new(), workers=Ws}}.
