Hint: on {error, busy}, do receive after 50 -> ok end then retry, bounded by MaxWaitMs.
