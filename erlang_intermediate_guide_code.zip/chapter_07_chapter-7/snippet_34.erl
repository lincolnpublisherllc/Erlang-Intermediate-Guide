Validate drain/1 returns {ok, drained} under load
