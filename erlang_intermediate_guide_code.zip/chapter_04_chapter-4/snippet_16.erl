-record(idx, {
    by_id    = gb_trees:empty() :: gb_trees:tree(),                 %% id -> doc
    by_tag   = #{}               :: map(),                           %% tag -> ordset(id)
    by_time  = gb_trees:empty()  :: gb_trees:tree()                  %% ts -> ordset(id)
}).
-type idx() :: #idx{}.
