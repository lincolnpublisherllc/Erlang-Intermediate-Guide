1> Q0 = queue:new().
2> Q1 = queue:in(a, Q0).
3> {value, X, Q2} = queue:out(Q1), X.
a
