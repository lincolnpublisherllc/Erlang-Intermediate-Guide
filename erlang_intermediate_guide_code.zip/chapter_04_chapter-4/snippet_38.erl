Sending only what the receiver needs (ids, offsets).
