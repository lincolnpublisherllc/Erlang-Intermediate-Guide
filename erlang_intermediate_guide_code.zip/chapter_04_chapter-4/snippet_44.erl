Task: Implement ceiling(Key, Tree) that returns {ok, {K,V}} where K is the smallest key ≥ Key, else {error, none}.
