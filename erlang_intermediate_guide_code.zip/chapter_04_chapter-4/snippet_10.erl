-spec range({K, K}, gb_trees:tree()) -> [{K, V}] when K :: term(), V :: term().
range({Lo, Hi}, T) ->
    case gb_trees:iterator_from(Lo, T) of
        Iter -> take_until(Hi, Iter, [])
    end.
