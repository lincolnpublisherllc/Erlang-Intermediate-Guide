file:write(Fd, [A, B, C]).   %% no intermediate concat
