take_until(Hi, Iter, Acc) ->
    case gb_trees:next(Iter) of
        none -> lists:reverse(Acc);
        {K, V, Iter1} when K =< Hi -> take_until(Hi, Iter1, [{K,V}|Acc]);
        {_K, _V, _} -> lists:reverse(Acc)
    end.
