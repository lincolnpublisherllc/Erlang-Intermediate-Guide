tag(I) -> list_to_atom("t" ++ integer_to_list(I)).
