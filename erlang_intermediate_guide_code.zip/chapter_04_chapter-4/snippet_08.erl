1> S = sets:from_list([1,2,3]).
{set,3,16,...}
2> sets:is_element(2, S).
true
3> sets:add_element(4, S).
{set,4,16,...}
Pick sets when you need faster membership on larger sets and order is irrelevant.
