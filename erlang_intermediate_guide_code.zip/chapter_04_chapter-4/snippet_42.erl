merge_top_n(L1, L2, N) ->
    take_n(ordsets:union(L1, L2), N).
