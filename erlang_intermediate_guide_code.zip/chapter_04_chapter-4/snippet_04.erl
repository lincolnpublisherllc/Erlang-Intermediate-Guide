Prefer maps:fold/3, gb_trees:fold/3, or lists:foreach/2 on ordsets.
