maps:put/3 returns a new map that reuses internal nodes. Cost ~ O(1) average, O(log n) worst.
