%% Pattern match by position
{user, Id, Name, Role} = User.
