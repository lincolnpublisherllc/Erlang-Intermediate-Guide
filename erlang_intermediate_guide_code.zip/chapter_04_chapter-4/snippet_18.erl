-spec add(idx(), doc()) -> idx().
add(I=#idx{by_id = Ids, by_tag = TagMap, by_time = Time}, #doc{id=Id, tags=Tags0, ts=Ts}) ->
    Tags = ordsets:from_list(Tags0),
    I1   = I#idx{by_id = gb_trees:enter(Id, {Tags, Ts}, Ids)},
    I2   = I1#idx{by_tag = add_tags(TagMap, Tags, Id)},
    I3   = I2#idx{by_time = add_time(Time, Ts, Id)},
    I3.
