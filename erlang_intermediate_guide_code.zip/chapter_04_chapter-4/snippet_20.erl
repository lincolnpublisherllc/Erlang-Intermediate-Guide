add_time(TimeTree, Ts, Id) ->
    case gb_trees:lookup(Ts, TimeTree) of
        none          -> gb_trees:enter(Ts, ordsets:from_list([Id]), TimeTree);
        {value, OSet} -> gb_trees:update(Ts, ordsets:add_element(Id, OSet), TimeTree)
    end.
