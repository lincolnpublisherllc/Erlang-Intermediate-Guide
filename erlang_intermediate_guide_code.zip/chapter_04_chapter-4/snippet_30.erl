gen_docs(N, K, T) ->
    lists:map(
      fun(Id) ->
          Tags = ordsets:from_list([tag((Id*7+J) rem T) || J <- lists:seq(1,K)]),
          #doc{id=Id, tags=Tags, ts=1000 + (Id rem 1000)}
      end, lists:seq(1,N)).
