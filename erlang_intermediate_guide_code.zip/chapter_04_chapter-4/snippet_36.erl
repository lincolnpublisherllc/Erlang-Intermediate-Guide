Bin = <<A/binary, B/binary, C/binary>>.
file:write(Fd, Bin).
