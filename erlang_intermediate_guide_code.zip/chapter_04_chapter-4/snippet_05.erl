%% {user, Id :: integer(), Name :: string(), Role :: atom()}
User = {user, 42, "Ada", admin}.
