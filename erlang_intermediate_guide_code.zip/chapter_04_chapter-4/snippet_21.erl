-spec by_tag(idx(), atom()) -> [integer()].
by_tag(#idx{by_tag = TagMap}, Tag) ->
    maps:get(Tag, TagMap, []).
