1> c(idx_core).
{ok,idx_core}
2> I0 = idx_core:empty().
3> D1 = #doc{id=1, tags=[a,c], ts=1000}.
4> D2 = #doc{id=2, tags=[b,c], ts=1100}.
5> I1 = idx_core:add(I0, D1).
6> I2 = idx_core:add(I1, D2).
7> idx_core:by_tag(I2, c).
[1,2]
8> idx_core:by_time(I2, {900, 1050}).
[1]
9> idx_core:and_tags(I2, [a,c]).
[1]
