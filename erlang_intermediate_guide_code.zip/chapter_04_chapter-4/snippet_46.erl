How to implement an ordered index with gb_trees and ordsets, and when a hashed approach or ETS may be better.
