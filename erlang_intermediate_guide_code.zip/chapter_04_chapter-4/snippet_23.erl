range_time({Lo,Hi}, T) ->
    I0 = gb_trees:iterator_from(Lo, T),
    gather(Hi, I0, []).
