add_tags(TagMap, Tags, Id) ->
    lists:foldl(fun(Tag, Acc) ->
                        Old = maps:get(Tag, Acc, []),
                        maps:put(Tag, ordsets:add_element(Id, Old), Acc)
                end, TagMap, Tags).
