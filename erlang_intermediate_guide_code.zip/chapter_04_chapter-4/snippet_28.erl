run() ->
    %% Generate N docs each with K tags from T distinct tags.
    N = 10000, K = 3, T = 200,
    Docs = gen_docs(N, K, T),
    IOrd = lists:foldl(fun idx_core:add/2, idx_core:empty(), Docs),
    %% Build an alternative tag map using maps of maps:
    MM = build_mapmap(Docs),
    TagPair = {tag(10), tag(20)},   %% intersect two common tags
    time("ordsets_intersect", fun() -> ord_intersect(IOrd, TagPair) end),
    time("mapmap_intersect", fun() -> mapmap_intersect(MM, TagPair) end),
    ok.
