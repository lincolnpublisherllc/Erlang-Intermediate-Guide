-spec by_time(idx(), {integer(), integer()}) -> [integer()].
by_time(#idx{by_time = T}, {From, To}) ->
    lists:usort([Id || {_, Ids} <- range_time({From,To}, T), Id <- Ids]).
