take_n(L, N) when N =< 0 -> [];
take_n([], _N) -> [];
take_n([H|T], N) -> [H | take_n(T, N-1)].
