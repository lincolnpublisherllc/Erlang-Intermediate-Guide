Each document has {id :: int(), tags :: ordset(atom()), ts :: integer()}.
