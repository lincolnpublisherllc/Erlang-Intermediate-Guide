Tuples: fixed-size, positional fields. Constant-time element access. Great for tags like {ok, Value} or small records.
