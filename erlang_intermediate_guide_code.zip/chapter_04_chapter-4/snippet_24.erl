gather(Hi, Iter, Acc) ->
    case gb_trees:next(Iter) of
        none -> lists:reverse(Acc);
        {Ts, Ids, Iter1} when Ts =< Hi -> gather(Hi, Iter1, [{Ts, Ids}|Acc]);
        _ -> lists:reverse(Acc)
    end.
