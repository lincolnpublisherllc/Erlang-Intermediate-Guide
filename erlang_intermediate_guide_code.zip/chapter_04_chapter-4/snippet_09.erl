1> T0 = gb_trees:empty().
{0,nil}
2> T1 = gb_trees:enter(10, foo, T0).
{1,{10,foo,nil,nil}}
3> T2 = gb_trees:enter(5, bar, T1).
4> gb_trees:lookup(10, T2).
{value,foo}
5> gb_trees:smallest(T2).
{5,bar}
