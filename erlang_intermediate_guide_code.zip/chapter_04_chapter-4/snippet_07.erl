1> S0 = ordsets:from_list([c,a,b]).
[a,b,c]
2> S1 = ordsets:add_element(d, S0).
[a,b,c,d]
3> ordsets:is_element(b, S1).
true
4> ordsets:intersection([a,b,d], [b,c,d]).
[b,d]
