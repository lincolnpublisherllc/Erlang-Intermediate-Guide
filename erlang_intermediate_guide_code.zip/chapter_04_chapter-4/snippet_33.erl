mapmap_intersect(MM, {T1, T2}) ->
    M1 = maps:get(T1, MM, #{}),
    M2 = maps:get(T2, MM, #{}),
    %% iterate smaller map, test membership in larger map
    {Small, Large} = if maps:size(M1) =< maps:size(M2) -> {M1, M2}; true -> {M2, M1} end,
    It = maps:iterator(Small),
    loop_map(It, Large, 0).
