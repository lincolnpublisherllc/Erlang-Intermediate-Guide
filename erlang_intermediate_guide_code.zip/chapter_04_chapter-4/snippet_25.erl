-spec and_tags(idx(), [atom()]) -> [integer()].
and_tags(#idx{by_tag = TM}, Tags) when Tags =/= [] ->
    %% Start from smallest posting list to reduce work
    Lists = [maps:get(T, TM, []) || T <- Tags],
    case lists:sort(fun length/1, Lists) of
        []      -> [];
        [L|Ls]  -> lists:foldl(fun ordsets:intersection/2, L, Ls)
    end;
and_tags(_, _) -> [].
