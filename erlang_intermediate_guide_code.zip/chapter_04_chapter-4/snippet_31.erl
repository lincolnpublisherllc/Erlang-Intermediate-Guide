build_mapmap(Docs) ->
    lists:foldl(fun(#doc{id=Id, tags=Tags}, Acc) ->
        lists:foldl(fun(Tag, AM) ->
            Inner = maps:get(Tag, AM, #{}),
            maps:put(Tag, maps:put(Id, true, Inner), AM)
        end, Acc, Tags)
    end, #{}, Docs).
