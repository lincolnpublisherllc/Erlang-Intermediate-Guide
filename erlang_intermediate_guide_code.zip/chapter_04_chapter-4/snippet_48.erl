Ship your findings with a short README: when you would switch from inproc to ets, and why.
