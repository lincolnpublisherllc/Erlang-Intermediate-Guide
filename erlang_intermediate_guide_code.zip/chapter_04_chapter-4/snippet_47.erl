start(Engine) -> Ref.
add(Ref, #doc{}) -> ok.
by_tag(Ref, Tag) -> [Id].
by_time(Ref, FromTo) -> [Id].
and_tags(Ref, Tags) -> [Id].
