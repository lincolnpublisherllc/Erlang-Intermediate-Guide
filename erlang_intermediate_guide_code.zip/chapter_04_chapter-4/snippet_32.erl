ord_intersect(I, {T1, T2}) ->
    lists:sum(idx_core:and_tags(I, [T1, T2])).
