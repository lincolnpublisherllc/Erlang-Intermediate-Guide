loop_map(It, Large, Acc) ->
    case maps:next(It) of
        none -> Acc;
        {Id, _Val, It1} ->
            Acc1 = case maps:is_key(Id, Large) of true -> Acc + Id; false -> Acc end,
            loop_map(It1, Large, Acc1)
    end.
