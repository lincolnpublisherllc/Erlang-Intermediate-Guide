%% Extracted from document — source marker: idx_core.erl
-module(idx_core).
-export([empty/0, add/2, by_tag/2, by_time/2, and_tags/2]).
