ceiling(Key, T) ->
    It = gb_trees:iterator_from(Key, T),
    case gb_trees:next(It) of
        none -> {error, none};
        {K,V,_} -> {ok, {K,V}}
    end.
