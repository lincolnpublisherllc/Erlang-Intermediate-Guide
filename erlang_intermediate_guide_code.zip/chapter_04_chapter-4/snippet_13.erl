T = ets:new(cache, [set, public, named_table]),
ets:insert(cache, {Key, Val}),
case ets:lookup(cache, Key) of
  [{_, V}] -> V;
  []       -> not_found
end.
