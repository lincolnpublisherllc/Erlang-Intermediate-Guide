%% Extracted from document — source marker: idx_bench.erl
-module(idx_bench).
-export([run/0]).
