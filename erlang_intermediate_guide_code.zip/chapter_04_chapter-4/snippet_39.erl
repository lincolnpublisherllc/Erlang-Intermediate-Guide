T = ets:new(idx_by_tag, [bag, public, named_table]),
%% bag allows multiple objects with same key Tag
ets:insert(idx_by_tag, {Tag, Id}),
%% by_time could be an ordered_set keyed by {Ts, Id}
T2 = ets:new(idx_by_time, [ordered_set, public, named_table]),
ets:insert(idx_by_time, {{Ts, Id}, true}).
