time(Label, F) ->
    {Micros, Res} = timer:tc(F),
    io:format("~s: ~p us  (res=~p)~n", [Label, Micros, Res]).
