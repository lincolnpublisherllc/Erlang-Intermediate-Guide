-spec empty() -> idx().
empty() -> #idx{}.
