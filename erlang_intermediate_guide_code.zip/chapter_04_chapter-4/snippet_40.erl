-spec safe_slice(binary(), non_neg_integer(), non_neg_integer()) -> binary().
safe_slice(Bin, Start, Len) ->
    <<_:Start/binary, Part:Len/binary, _/binary>> = Bin,
    binary:copy(Part).
