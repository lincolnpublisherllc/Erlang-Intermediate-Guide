drain(Q, N) when N =< 0 -> {[], Q};
drain(Q, N) ->
    case queue:out(Q) of
        {empty, _}         -> {[], Q};
        {{value, X}, Q1} ->
            {Rest, Q2} = drain(Q1, N-1),
            {[X|Rest], Q2}
    end.
