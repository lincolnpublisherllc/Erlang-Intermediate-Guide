maps of maps where TagMap is Tag -> #{Id => true}
