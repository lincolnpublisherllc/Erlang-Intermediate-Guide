start_link() ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, [], []).
