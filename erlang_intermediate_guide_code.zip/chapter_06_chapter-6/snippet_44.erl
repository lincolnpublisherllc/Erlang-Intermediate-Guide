prop_roundtrip() ->
  ?FORALL({Ts, Msg},
    {non_neg_integer(), binary()},
    begin
      Line = iolist_to_binary([<<"ts=">>, integer_to_binary(Ts), <<" msg=">>, Msg]),
      case parse_ts:from_line(Line) of
        {ok, #{ts := Ts2, msg := Msg2}} ->
            Ts2 =:= Ts andalso Msg2 =:= Msg;
        _ -> false
      end
    end).
