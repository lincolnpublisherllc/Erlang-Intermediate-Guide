value(<<"msg=", V/binary>>) -> V;
value(_) -> <<>>.
