Pid = whereis(fail_worker),
recon:info(Pid, [current_function, message_queue_len, memory, dictionary]).
