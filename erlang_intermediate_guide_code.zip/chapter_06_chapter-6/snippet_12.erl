1> {ok, _} = fail_sup:start_link().
2> fail_worker:set(a, 1).
ok
3> fail_worker:get(b).
%% crash: bad key causes exception; supervisor restarts the server
