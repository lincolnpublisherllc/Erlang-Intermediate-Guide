%% Extracted from document — source marker: csv_prop_tests.erl
-module(csv_prop_tests).
-include_lib("proper/include/proper.hrl").
