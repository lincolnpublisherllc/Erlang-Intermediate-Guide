logger:info("set ~p=~p", [Key, Val], #{component => fail_worker, key => Key}),
logger:error("unexpected input ~p", [Msg], #{component => "ingest", step => "parse"}).
