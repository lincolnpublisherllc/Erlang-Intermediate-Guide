bad_ts_test() ->
    ?assertMatch({error, _}, catch parse_ts:from_line(<<"ts=x msg=hi">>)).  %% currently crashes
