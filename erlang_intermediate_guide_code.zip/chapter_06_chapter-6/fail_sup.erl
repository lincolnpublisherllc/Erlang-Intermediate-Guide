%% Extracted from document — source marker: fail_sup.erl
-module(fail_sup).
-behaviour(supervisor).
-export([start_link/0, init/1]).
