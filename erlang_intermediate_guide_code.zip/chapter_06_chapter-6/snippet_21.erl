Add PropEr to rebar.config test profile, then write a generator and property. Example: a CSV splitter should rejoin into the original line when fields have no commas or quotes.
