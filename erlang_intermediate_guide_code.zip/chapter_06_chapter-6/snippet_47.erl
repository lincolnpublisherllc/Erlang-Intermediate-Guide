erlang:trace(all, true, [call]),
erlang:trace_pattern({parse_ts, to_int, 1}, true, []),
timer:sleep(100),
erlang:trace_pattern({parse_ts, to_int, 1}, false, []),
erlang:trace(all, false, [call]).
