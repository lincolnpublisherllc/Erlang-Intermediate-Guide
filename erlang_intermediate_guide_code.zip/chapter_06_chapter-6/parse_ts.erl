%% Extracted from document — source marker: parse_ts.erl
-module(parse_ts).
-export([from_line/1]).
