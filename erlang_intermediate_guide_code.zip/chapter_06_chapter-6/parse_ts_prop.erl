%% Extracted from document — source marker: parse_ts_prop.erl
-module(parse_ts_prop).
-include_lib("proper/include/proper.hrl").
