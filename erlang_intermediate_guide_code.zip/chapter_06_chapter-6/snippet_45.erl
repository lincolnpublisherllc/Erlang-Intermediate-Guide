Guard mailboxes: if a server receives unbounded messages, consider limiting producers or splitting load.
