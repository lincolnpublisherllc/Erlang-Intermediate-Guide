A small OTP application:
