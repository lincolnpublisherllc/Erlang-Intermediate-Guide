prop_split_join_idempotent() ->
    ?FORALL(Fields, list(binary()),
      begin
        Line = iolist_to_binary(intersperse(Fields, <<",">>)),
        Fields =:= csv_small:split(Line)
      end).
