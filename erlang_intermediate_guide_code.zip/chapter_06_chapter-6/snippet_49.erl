How to structure fault-tolerant services with supervisors and clear restart strategies.
