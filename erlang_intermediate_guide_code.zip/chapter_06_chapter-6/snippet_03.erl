If the process is a child of a supervisor, the supervisor applies its strategy:
