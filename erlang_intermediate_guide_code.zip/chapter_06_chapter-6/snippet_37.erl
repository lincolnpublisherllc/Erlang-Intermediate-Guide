value(<<"msg=", V/binary>>) -> V;
value(_) -> error(bad_msg).
Bug: if ts= is not an integer, we raise with error(bad_ts) which crashes callers. We want {error, bad_ts}.
