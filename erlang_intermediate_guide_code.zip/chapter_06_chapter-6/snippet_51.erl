A supervisor with one_for_one and a max_restarts window
