from_line(Line) when is_binary(Line) ->
    case binary:split(Line, <<" ">>, [global]) of
        [TsK, MsgK] ->
            case to_int(TsK) of
                {ok, I}      -> {ok, #{ts => I, msg => value(MsgK)}};
                {error, Why} -> {error, Why}
            end;
        _ ->
            {error, bad_format}
    end.
