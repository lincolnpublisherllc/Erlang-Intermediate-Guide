parse_ts:from_line/1 expects "ts=<int> msg=<text>" and returns {ok, #{ts => Int, msg => Bin}} or {error, Reason}. We will intentionally miss an edge case to see a failure.
