Trace all calls to maps:get/2 made by our worker:
Pid = whereis(fail_worker),
erlang:trace(Pid, true, [call]),
erlang:trace_pattern({maps, get, 2}, true, []),
%% trigger activity
fail_worker:get(a),
erlang:trace_pattern({maps, get, 2}, false, []),
erlang:trace(Pid, false, [call]).
You will receive {trace, Pid, call, {maps,get,[K,Map]}} messages in the shell. Use judiciously.
