ok_line_test() ->
    {ok, M} = parse_ts:from_line(<<"ts=100 msg=hi">>),
    ?assertEqual(100, maps:get(ts, M)).
