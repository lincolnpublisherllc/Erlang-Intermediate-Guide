to_int(<<"ts=", Num/binary>>) ->
    case string:to_integer(binary_to_list(Num)) of
        {I, _} -> I;
        error  -> error(bad_ts)
    end.
