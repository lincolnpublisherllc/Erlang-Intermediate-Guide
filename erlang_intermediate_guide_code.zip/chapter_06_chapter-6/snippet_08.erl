handle_call({set, K, V}, _From, S=#st{store=Map}) ->
    {reply, ok, S#st{store=Map#{K => V}}};
handle_call({get, K}, _From, S=#st{store=Map}) ->
    {reply, maps:get(K, Map), S};  %% will crash if K missing; good for demo
handle_call({boom, div_zero}, _From, S) ->
    _ = 1 div 0, {reply, ok, S};
handle_call({boom, badmatch}, _From, S) ->
    {ok, X} = {error, nope}, {reply, X, S};
handle_call(_, _, S) -> {reply, {error, bad_call}, S}.
