Trace BIFs: erlang:trace/3, erlang:trace_pattern/3
