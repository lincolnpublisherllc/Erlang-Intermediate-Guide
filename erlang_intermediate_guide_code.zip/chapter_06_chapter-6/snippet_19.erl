init_per_suite(Config) ->
    application:ensure_all_started(yourapp), Config.
end_per_suite(_Config) ->
    application:stop(yourapp), ok.
