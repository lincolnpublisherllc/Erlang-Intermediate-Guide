init([]) ->
    Worker = #{id => fail_worker, start => {fail_worker, start_link, []},
               restart => permanent, shutdown => 5000, type => worker, modules => [fail_worker]},
    {ok, {{one_for_one, 3, 5}, [Worker]}}.
