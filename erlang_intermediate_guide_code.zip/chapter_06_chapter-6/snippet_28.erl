sys:trace(whereis(fail_worker), true),
fail_worker:set(a, 1),
sys:trace(whereis(fail_worker), false).
