intersperse([], _S)      -> [];
intersperse([X], _S)     -> [X];
intersperse([X|Xs], Sep) -> [X, Sep | intersperse(Xs, Sep)].
