rebar3 as test proper
Start with simple properties. Add edge-case generators as you grow confidence.
