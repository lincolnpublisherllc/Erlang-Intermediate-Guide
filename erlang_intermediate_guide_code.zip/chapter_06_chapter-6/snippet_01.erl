supervisors restart crashed workers using a clear policy
