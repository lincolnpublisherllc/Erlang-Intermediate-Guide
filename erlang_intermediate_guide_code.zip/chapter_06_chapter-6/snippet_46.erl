Solution (supervisor spec):
{ok, {{one_for_one, 3, 2}, [Worker]}}.
In CT, call boom/1 four times quickly and assert {error, {not_found, fail_worker}} or a failed start_link.
