restart_on_crash(_Cfg) ->
    {ok, _} = fail_worker:set(k, v),
    _ = catch fail_worker:boom(div_zero),
    timer:sleep(50),
    ?assertEqual(ok, fail_worker:set(k, v2)).
This asserts the supervisor kept the service available after a crash.
