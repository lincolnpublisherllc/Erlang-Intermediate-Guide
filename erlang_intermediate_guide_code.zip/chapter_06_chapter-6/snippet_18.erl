all() -> [restart_on_crash].
