[
  {kernel, [{logger_level, info}]},
  {sasl, [{sasl_error_logger, false}, {errlog_type, error}]}
].
