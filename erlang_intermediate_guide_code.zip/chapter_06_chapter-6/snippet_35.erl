from_line(Line) when is_binary(Line) ->
    case binary:split(Line, <<" ">>, [global]) of
        [TsK, MsgK] ->
            {ok, #{ts => to_int(TsK), msg => value(MsgK)}};
        _ ->
            {error, bad_format}
    end.
