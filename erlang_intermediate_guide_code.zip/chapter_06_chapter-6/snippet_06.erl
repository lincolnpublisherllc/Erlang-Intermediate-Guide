set(Key, Val) -> gen_server:call(?MODULE, {set, Key, Val}).
get(Key)      -> gen_server:call(?MODULE, {get, Key}).
boom(Why)     -> gen_server:call(?MODULE, {boom, Why}).
