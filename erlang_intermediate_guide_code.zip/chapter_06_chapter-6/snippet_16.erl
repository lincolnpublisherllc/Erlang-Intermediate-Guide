get_crashes_on_missing_test() ->
    {ok, _} = fail_sup:start_link(),
    ?assertError(_, fail_worker:get(missing)).
