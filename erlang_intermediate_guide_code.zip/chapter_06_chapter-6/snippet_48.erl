CleanBin() ->
  ?LET(L, list(oneof([$a,$b,$c,$d,$e,$f, $0,$1,$2,$3, $_, $-])),
       list_to_binary(L)).
?FORALL({Ts, Msg}, {non_neg_integer(), CleanBin()}, ...).
