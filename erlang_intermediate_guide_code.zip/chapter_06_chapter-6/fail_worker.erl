%% Extracted from document — source marker: fail_worker.erl
-module(fail_worker).
-behaviour(gen_server).
-export([start_link/0, set/2, get/1, boom/1]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2, terminate/2, code_change/3]).
