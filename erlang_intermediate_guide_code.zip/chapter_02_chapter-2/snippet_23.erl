Keep release metadata in rel/VERSION and inject into the application at compile time (e.g., -define(VSN, "0.1.0"). or read from application:get_key/2).
