{aliases, [
  {ci, ["as test dialyzer", "as test ct", "as prod release"]}
]}.
