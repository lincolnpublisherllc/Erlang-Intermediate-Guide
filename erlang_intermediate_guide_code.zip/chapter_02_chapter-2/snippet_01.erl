rebar3 new release app_name=myapp
cd myapp
