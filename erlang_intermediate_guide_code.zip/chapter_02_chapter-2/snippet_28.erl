      - name: Dialyzer
        run: rebar3 as test dialyzer
