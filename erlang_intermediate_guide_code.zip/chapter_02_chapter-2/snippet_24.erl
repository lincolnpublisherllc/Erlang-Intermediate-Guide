name: ci
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    env:
      REBAR_COLOR: 1
    steps:
      - uses: actions/checkout@v4
