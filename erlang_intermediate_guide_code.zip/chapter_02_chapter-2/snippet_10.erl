Your code reads configuration via application:get_env(App, Key, Default).
