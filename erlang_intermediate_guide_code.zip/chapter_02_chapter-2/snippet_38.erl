{profiles, [
  {prod, [
    {relx, [
      {sys_config, "config/sys.config.prod"},
      {vm_args, "config/vm.args"},
      {dev_mode, false},
      {include_erts, true}
    ]}
  ]}
]}.
