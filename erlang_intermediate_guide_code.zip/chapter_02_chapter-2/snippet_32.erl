.PHONY: build test dialyzer release ci
build: ; rebar3 compile
test:  ; rebar3 as test ct
dialyzer: ; rebar3 as test dialyzer
release: ; rebar3 as prod release
ci: build dialyzer test release
