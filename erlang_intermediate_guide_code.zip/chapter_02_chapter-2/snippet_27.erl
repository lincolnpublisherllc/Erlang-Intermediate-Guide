      - name: Compile
        run: rebar3 compile
