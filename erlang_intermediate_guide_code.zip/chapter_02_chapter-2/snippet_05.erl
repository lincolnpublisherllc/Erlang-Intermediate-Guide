%% Lock file is generated on first fetch:
%%   rebar.lock (commit to VCS!)
