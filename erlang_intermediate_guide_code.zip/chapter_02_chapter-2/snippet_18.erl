all() -> [healthy_starts].
