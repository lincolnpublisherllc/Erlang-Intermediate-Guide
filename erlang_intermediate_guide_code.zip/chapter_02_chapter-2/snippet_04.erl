{deps, [
  %% JSON parser example (pin version)
  {jsx, "3.1.0"},
  %% HTTP client example (pin version)
  {gun, "2.0.1"}
]}.
