rebar3 release                    # dev tar in _build/default/rel/myapp
rebar3 as prod release            # prod-grade tar with ERTS included
