      - name: Common Test
        run: rebar3 as test ct
