{aliases, [
  {check, ["compile", "as test dialyzer", "as test ct"]}
]}.
