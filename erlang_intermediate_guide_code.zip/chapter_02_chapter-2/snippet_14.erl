{relx, [
  {release, {myapp, "0.1.0"}, [myapp]},
  {sys_config, "config/sys.config"},
  {vm_args, "config/vm.args"},
  {dev_mode, true},
  {include_erts, false}
]}.
