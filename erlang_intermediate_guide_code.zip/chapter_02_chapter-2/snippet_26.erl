      - name: Cache rebar deps
        uses: actions/cache@v4
        with:
          path: |
            ~/.cache/rebar3
            _build
          key: deps-${{ runner.os }}-otp26-${{ hashFiles('rebar.lock') }}
          restore-keys: |
            deps-${{ runner.os }}-otp26-
