myapp/
├─ apps/
│  └─ myapp/
│     ├─ src/
│     │  ├─ myapp_app.erl        % application callback
│     │  ├─ myapp_sup.erl        % top-level supervisor
│     │  └─ myapp.erl            % public API (example)
│     └─ test/                   % common_test suites live here
├─ config/
│  ├─ sys.config                 % runtime application env (default)
│  ├─ sys.config.dev             % dev overrides
│  ├─ sys.config.test            % test overrides
│  ├─ sys.config.prod            % prod config (never hardcode secrets)
│  └─ vm.args                    % VM flags (cookie, schedulers, etc.)
├─ rebar.config
└─ rel/
   └─ overlays/                  % files injected into the release
