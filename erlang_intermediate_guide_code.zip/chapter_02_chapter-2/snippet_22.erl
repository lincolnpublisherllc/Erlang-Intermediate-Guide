rebar3 as test ct
