healthy_starts(_Config) ->
    application:ensure_all_started(myapp),
    ?assertEqual(ok, myapp:health()),
    application:stop(myapp),
    ok.
