-setcookie ${MYAPP_COOKIE}
-name myapp@127.0.0.1
+K true
+A 16
+sbwt none
