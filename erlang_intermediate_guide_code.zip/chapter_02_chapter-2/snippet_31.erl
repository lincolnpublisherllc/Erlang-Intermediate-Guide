      - name: Upload release tar
        uses: actions/upload-artifact@v4
        with:
          name: myapp-release
          path: _build/prod/rel/myapp/releases/*/*.tar.gz
