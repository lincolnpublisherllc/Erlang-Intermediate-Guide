_build/default/rel/myapp/bin/myapp console
