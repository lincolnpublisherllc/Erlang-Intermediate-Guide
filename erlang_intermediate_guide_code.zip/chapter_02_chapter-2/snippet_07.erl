  {test, [
     {deps, []},
     {ct_opts, [
        {dir, "apps/myapp/test"},
        {logdir, "_build/test/logs"},
        {abort_if_missing_suites, true}
     ]},
     {erl_opts, [nowarn_export_all]}   % tests often export helpers
  ]},
