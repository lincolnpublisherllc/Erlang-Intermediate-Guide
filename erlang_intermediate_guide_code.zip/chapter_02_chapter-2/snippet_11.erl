[
  {myapp, [
     {http_port, 8080},
     {db_url, "postgres://localhost/myapp_dev"},
     {log_level, info}
  ]}
].
