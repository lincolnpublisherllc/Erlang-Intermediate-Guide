      - name: Build prod release
        run: rebar3 as prod release
