{relx, [
  {release, {myapp, "0.1.0"}, [myapp]},
  {overlay, [
     {copy, "config/vm.args", "releases/{{release_version}}/vm.args"},
     {copy, "config/sys.config", "releases/{{release_version}}/sys.config"},
     {template, "rel/overlays/bin/render-config", "bin/render-config", []}
  ]}
]}.
