{erl_opts, [warn_export_all, warn_missing_spec, warn_untyped_record]}.
