[{myapp, [{http_port, 8080}]}].
