rebar3 as test ct
rebar3 as prod release
_build/prod/rel/myapp/bin/myapp console
