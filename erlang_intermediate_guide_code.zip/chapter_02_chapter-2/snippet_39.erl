apps/myapp/ with a supervisor, an example worker (periodic timer logs), and one CT suite.
