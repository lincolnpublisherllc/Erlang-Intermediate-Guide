  {prod, [
     {relx, [{dev_mode, false}, {include_erts, true}]},
     {dialyzer, [{plt_file, "_build/prod/dialyzer.plt"}]}
  ]}
]}.
