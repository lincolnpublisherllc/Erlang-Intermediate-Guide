{profiles, [
  {dev, [
     {deps, []},
     {relx, [{dev_mode, true}]},       % fast, no tar
     {dialyzer, [
        {plt_file, "_build/dev/dialyzer.plt"},
        {warnings, [no_return, unmatched_returns, error_handling]}
     ]}
  ]},
