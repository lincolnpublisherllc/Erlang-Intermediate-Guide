rebar3 as dev ct          # run Common Test in dev env
rebar3 as test do ct      # force test profile
rebar3 as prod release
