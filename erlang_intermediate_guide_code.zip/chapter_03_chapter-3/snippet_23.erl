Include shapes in the doc (e.g., {ok, Count} | {error, rate_limited})
