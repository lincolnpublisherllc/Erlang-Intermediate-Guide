%% Extracted from document — source marker: mylib_core/src/mylib_core_backend.erl
-module(mylib_core_backend).
-behaviour(gen_lib_backend).   %% <— our custom behaviour
-export([init/1, fetch/2, store/3]).
