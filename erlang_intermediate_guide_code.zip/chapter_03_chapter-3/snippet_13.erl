%% API
-spec start_link({non_neg_integer(), pos_integer()}) -> {ok, pid()} | {error, term()}.
start_link(Policy) ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, Policy, []).
