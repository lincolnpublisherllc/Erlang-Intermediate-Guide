handle_call({inc, Key}, _From, S = #st{store = Store, policy = Pol}) ->
    Now = erlang:monotonic_time(millisecond),
    case mylib_core_counter:bump(Key, Now, Store, Pol) of
        {ok, N, Store1}            -> {reply, {ok, N}, S#st{store = Store1}};
        {error, rate_limited, S1}  -> {reply, {error, rate_limited}, S#st{store = S1}}
    end;
handle_call({get, Key}, _From, S = #st{store = Store}) ->
    {ok, N} = mylib_core_counter:get(Key, Store),
    {reply, {ok, N}, S};
handle_call(_Else, _From, S) ->
    {reply, {error, bad_call}, S}.
