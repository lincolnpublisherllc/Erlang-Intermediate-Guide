Task: Add peek/2 that returns {ok, Count, OldestMs, NewestMs} for a key (or {ok, 0, undefined, undefined}).
