%% Extracted from document — source marker: mylib_core/src/mylib_core_limit.erl
-module(mylib_core_limit).
-export([should_allow/3]).  % Rate limit: {window_ms, max_hits}
