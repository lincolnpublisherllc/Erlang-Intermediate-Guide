handle_call({inc, Key}, _From, S = #st{store = Store, policy = {Win, Max}}) ->
    Now = erlang:monotonic_time(millisecond),
    case mylib_core_counter:bump(Key, Now, Store, {Win, Max}) of
        {ok, N, Store1}            -> {reply, {ok, N, Max-N}, S#st{store = Store1}};
        {error, rate_limited, S1}  -> {reply, {error, rate_limited, 0}, S#st{store = S1}}
    end.
