Srv: state, concurrency, timers, external I/O; OTP behaviours (gen_server, supervisor, gen_statem).
