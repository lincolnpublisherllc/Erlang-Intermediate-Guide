%% @doc Decide if a hit is allowed given now, recent hits, and policy.
-spec should_allow(non_neg_integer(), [non_neg_integer()], {non_neg_integer(), pos_integer()})
      -> {allow, [non_neg_integer()]} | {deny, [non_neg_integer()]}.
should_allow(NowMs, HitsAsc, {WindowMs, Max}) ->
    Pruned = [T || T <- HitsAsc, T + WindowMs > NowMs],
    case length(Pruned) < Max of
        true  -> {allow, Pruned};
        false -> {deny,  Pruned}
    end.
