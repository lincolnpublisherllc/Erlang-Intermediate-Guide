store(Key, Val, State) ->
    {ok, maps:put(Key, Val, State)}.
