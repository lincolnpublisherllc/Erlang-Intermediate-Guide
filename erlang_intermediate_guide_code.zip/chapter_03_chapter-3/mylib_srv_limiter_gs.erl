%% Extracted from document — source marker: mylib_srv/src/mylib_srv_limiter_gs.erl
-module(mylib_srv_limiter_gs).
-behaviour(gen_server).
-export([start_link/1, inc/2, get/2]).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
         terminate/2, code_change/3]).
