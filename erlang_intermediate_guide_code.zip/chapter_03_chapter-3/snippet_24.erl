%% @doc Increment per-key hit with policy {WindowMs, Max}.
%% Returns {ok, NewCount} or {error, rate_limited}.
