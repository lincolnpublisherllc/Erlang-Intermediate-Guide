Solution hint: Create mylib_srv_backend.erl with -callback attributes:
-callback init(Opts :: term()) -> {ok, State :: term()} | {error, term()}.
-callback fetch(Key :: term(), State :: term())
        -> {ok, Val :: term(), State :: term()} | {error, not_found, State :: term()}.
-callback store(Key :: term(), Val :: term(), State :: term())
        -> {ok, State :: term()} | {error, term(), State :: term()}.
