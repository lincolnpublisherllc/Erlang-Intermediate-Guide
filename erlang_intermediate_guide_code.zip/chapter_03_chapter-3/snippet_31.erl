erl -pa _build/default/lib/*/ebin -noshell -s mylib_cli_main run
