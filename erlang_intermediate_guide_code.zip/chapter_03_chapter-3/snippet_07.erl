fetch(Key, State = #{}) ->
    case maps:get(Key, State, undefined) of
        undefined -> {error, not_found, State};
        Val       -> {ok, Val, State}
    end.
