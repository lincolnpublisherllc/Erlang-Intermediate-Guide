Provide runtime wiring (e.g., gen_server loop).
