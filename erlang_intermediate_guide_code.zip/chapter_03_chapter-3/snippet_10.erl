%% @doc Bump key's hits; returns new count and updated map.
-spec bump(term(), non_neg_integer(), map(), {non_neg_integer(), pos_integer()})
        -> {ok, non_neg_integer(), map()} | {error, rate_limited, map()}.
bump(Key, NowMs, Store, Policy) ->
    Hits = maps:get(Key, Store, []),
    case mylib_core_limit:should_allow(NowMs, Hits, Policy) of
        {allow, Kept} ->
            NewHits = Kept ++ [NowMs],
            {ok, length(NewHits), maps:put(Key, NewHits, Store)};
        {deny, Kept} ->
            {error, rate_limited, maps:put(Key, Kept, Store)}
    end.
