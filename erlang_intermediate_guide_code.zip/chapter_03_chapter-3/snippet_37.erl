peek(Key, Store) ->
    Hits = maps:get(Key, Store, []),
    case Hits of
        [] -> {ok, 0, undefined, undefined};
        _  -> {ok, length(Hits), hd(Hits), lists:last(Hits)}
    end.
