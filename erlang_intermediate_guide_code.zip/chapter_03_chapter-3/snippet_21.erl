3.6 Export lists: public vs private
