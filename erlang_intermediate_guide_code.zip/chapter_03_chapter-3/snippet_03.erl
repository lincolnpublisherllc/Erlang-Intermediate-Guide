apps/
  mylib_core/   % pure data + algorithms; no processes, no I/O
  mylib_srv/    % OTP processes, supervision trees
  mylib_cli/    % thin command-line or HTTP adapters; optional
