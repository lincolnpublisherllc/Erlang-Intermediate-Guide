run() ->
    {ok, Pid} = mylib_srv_limiter_gs:start_link({5_000, 3}), % 3 hits / 5s
    io:format("Limiter ready (3 hits/5s). Type keys, Ctrl+C to exit.~n"),
    loop(Pid).
