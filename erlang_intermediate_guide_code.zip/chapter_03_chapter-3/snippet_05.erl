gen_server: stateful server with request/response
supervisor: restart strategy for children
gen_statem: formal state machine
