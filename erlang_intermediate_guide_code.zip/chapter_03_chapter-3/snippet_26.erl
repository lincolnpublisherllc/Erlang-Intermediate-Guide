{apps, [mylib_core, mylib_srv, mylib_cli]}.
{deps, []}.
