%% Extracted from document — source marker: mylib_cli/src/mylib_cli_main.erl
-module(mylib_cli_main).
-export([run/0]).
