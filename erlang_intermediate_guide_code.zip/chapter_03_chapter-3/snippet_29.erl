core_allows_then_denies(_Cfg) ->
    Now = 1000,
    Pol = {1000, 2},  % 2 hits per 1s
    Store0 = #{},
    {ok, 1, S1} = mylib_core_counter:bump(k, Now, Store0, Pol),
    {ok, 2, S2} = mylib_core_counter:bump(k, Now+10, S1, Pol),
    {error, rate_limited, S3} = mylib_core_counter:bump(k, Now+20, S2, Pol),
    ?assertMatch(#{}, maps:without([k], S3)).
