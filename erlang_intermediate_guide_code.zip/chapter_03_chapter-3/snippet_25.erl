rebar3 new umbrella mylib
cd mylib
rebar3 new app mylib_core
rebar3 new app mylib_srv
rebar3 new app mylib_cli
