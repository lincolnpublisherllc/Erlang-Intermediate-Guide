Task: Add {ok, Remaining} to the limiter’s inc/2 reply, where Remaining = Max - Current.
