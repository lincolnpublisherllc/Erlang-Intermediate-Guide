%% Extracted from document — source marker: mylib_core/src/mylib_core_counter.erl
-module(mylib_core_counter).
-export([bump/4, get/2]).
