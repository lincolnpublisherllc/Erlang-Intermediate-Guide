GenServer mirrors gen_server with a different surface but the same semantics.
