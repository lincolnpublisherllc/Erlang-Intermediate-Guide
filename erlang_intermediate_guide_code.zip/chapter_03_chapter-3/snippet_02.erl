%% Goal: a rate-limited counter library (per key)
%% Public surface (stable):
%% - new/0 -> Ref
%% - inc(Ref, Key) -> {ok, NewCount} | {error, rate_limited}
%% - get(Ref, Key) -> {ok, Count}
