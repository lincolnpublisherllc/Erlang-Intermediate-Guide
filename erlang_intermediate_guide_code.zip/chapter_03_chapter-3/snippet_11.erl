-spec get(term(), map()) -> {ok, non_neg_integer()}.
get(Key, Store) ->
    {ok, length(maps:get(Key, Store, []))}.
