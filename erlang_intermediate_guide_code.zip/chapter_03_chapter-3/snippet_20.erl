loop(Pid) ->
    case io:get_line("> ") of
        eof -> ok;
        Line ->
            Key = string:trim(Line),
            case mylib_srv_limiter_gs:inc(Pid, Key) of
                {ok, N}             -> io:format("~s -> count=~p~n", [Key, N]);
                {error, rate_limited} -> io:format("~s -> RATE LIMITED~n", [Key])
            end,
            loop(Pid)
    end.
