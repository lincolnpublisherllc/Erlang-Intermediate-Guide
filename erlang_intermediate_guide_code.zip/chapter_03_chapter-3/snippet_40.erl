inc <key> → {ok, Count}
get <key> → {ok, Count}
switch ets|mem at runtime (restart the server gracefully under a supervisor).
