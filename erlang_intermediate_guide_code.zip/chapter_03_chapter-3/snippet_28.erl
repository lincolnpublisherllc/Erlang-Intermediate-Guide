all() -> [core_allows_then_denies].
