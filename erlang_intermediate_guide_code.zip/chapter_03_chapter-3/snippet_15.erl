-spec get(pid() | module(), term()) -> {ok, non_neg_integer()}.
get(Server, Key) ->
    gen_server:call(Server, {get, Key}).
