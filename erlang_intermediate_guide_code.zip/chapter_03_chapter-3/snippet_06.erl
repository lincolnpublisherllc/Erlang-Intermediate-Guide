%% Callback specs defined by the behaviour
init(Opts) -> {ok, #{opts => Opts}}.
