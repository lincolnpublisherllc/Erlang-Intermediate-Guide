Uses tagged tuples consistently ({ok, Value} | {error, Reason})
