-spec inc(pid() | module(), term()) -> {ok, non_neg_integer()} | {error, rate_limited}.
inc(Server, Key) ->
    gen_server:call(Server, {inc, Key}).
