How to implement a real workflow as a gen_statem with clean transitions and timeouts
