A producer process that keeps a buffer and only sends when asked: {ask, N, From}
One or more consumers that request batches with {ask, N, self()} when ready
