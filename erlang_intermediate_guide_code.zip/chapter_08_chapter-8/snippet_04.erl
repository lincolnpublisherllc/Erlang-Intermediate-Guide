gen_server → init/1, handle_call/3, handle_cast/2, …
gen_statem → callback_mode/0, init/1, per-state functions that return next_state and actions
Why gen_statem here?
State machines let you name phases and enforce allowed transitions, which fits payments: created → authorized → captured → settled and error paths.
