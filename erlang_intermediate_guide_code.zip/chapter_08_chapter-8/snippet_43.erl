8.6 Patterns: composition with supervisors
