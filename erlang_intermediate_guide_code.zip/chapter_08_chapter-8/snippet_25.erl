%%% State: authorized
