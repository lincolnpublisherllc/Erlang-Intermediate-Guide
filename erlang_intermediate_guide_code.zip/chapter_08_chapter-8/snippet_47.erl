Ref = make_ref(),
Server ! {capture, Ref, self(), #{amount => 100}},
receive
  {ok, Ref, Reply}    -> ...;
  {error, Ref, Why}   -> ...
after 3000 -> timeout
end.
