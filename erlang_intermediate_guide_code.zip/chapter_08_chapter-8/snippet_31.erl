state_captured({call, _From}, {settle, Ref, Client}, Data) ->
    emit_metric(settle_ok, state_captured, Data),
    reply(Client, Ref, ok, #{status => settled}),
    {next_state, state_settled, Data};
