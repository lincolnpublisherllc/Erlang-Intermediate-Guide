myapp_sup
 ├─ registry_gs
 ├─ pay_sup (simple_one_for_one)
 └─ http_adapter (Cowboy) → routes to pay_fsm via registry
