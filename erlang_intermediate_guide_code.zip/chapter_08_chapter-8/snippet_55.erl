Sketch solution: Update state_authorized to accept capture when Amt =< (A - CapturedTotal) and move to state_captured only when fully captured, else stay in state_authorized.
