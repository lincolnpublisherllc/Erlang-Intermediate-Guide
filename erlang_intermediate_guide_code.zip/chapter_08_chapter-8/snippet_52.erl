happy_path(_C) ->
    {ok,_} = pay_sup:start_link(),
    {ok,_} = pay_sup:start_payment(#{id => <<"t1">>, meta => #{}}),
    {ok,_} = pay_fsm:call(<<"t1">>, {authorize, #{amount=>100, card=><<"x">>}}),
    {ok,_} = pay_fsm:call(<<"t1">>, {capture, #{amount=>100}}),
    {ok,_} = pay_fsm:call(<<"t1">>, {settle}),
    ok.
