%% Extracted from document — source marker: pay_fsm.erl
-module(pay_fsm).
-behaviour(gen_statem).
