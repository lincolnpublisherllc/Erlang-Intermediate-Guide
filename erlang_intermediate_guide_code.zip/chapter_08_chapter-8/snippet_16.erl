callback_mode() -> state_functions.
