%%% Helpers: replies and metrics
