state_authorized({call, _From}, {capture, Ref, Client, #{amount := Amt}}, Data=#{amount := A}) ->
    case Amt =< A of
        true ->
            Data1 = Data#{captured => Amt},
            emit_metric(capture_ok, state_authorized, Data1),
            reply(Client, Ref, ok, #{status => captured, amount => Amt}),
            {next_state, state_captured, Data1, [{state_timeout, 5000, settle_timeout}]};
        false ->
            reply(Client, Ref, error, #{reason => over_capture}),
            keep_state_and_data
    end;
