new
 └─(authorize)→ authorized
authorized
 ├─(capture)→ captured
 └─(void)→ voided
captured
 └─(settle)→ settled
