state_authorized(state_timeout, void_timeout, Data) ->
    emit_metric(void_timeout, state_authorized, Data),
    {next_state, state_voided, Data};
