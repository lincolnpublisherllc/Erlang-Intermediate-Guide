state_new({call, From}, {authorize, Ref, Client, #{amount := Amt, card := Card}}, Data) ->
    %% Pretend to hit PSP; here we simulate success
    AuthId = crypto:strong_rand_bytes(8),
    Data1 = Data#{amount => Amt, auth_id => base64:encode(AuthId)},
    emit_metric(auth_ok, state_new, Data1),
    reply(Client, Ref, ok, #{status => authorized, auth_id => maps:get(auth_id, Data1)}),
    %% set 30m timer for auto-void if no capture (demo uses small ms)
    {next_state, state_authorized, Data1, [{state_timeout, 30*60*1000, void_timeout}]};
