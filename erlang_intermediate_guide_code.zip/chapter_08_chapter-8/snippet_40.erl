1> {ok,_} = pay_sup:start_link().
2> {ok, Pid} = pay_sup:start_payment(#{id => <<"p1">>, meta => #{}}).
3> pay_fsm:call(<<"p1">>, {authorize, #{amount => 100, card => <<"****">>}}).
{ok,#{auth_id => <<"...">>,status => authorized}}
4> pay_fsm:call(<<"p1">>, {capture, #{amount => 100}}).
{ok,#{amount => 100,status => captured}}
5> pay_fsm:call(<<"p1">>, {settle}).
{ok,#{status => settled}}
If you call capture after settled, you get {error, already_settled} by design.
