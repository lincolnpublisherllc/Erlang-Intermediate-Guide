Log state transitions with logger:info("~p -> ~p", [Old, New], Meta).
