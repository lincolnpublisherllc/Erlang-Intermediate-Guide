init(Init) ->
    Id = maps:get(id, Init),
    logger:metadata(#{component => pay_fsm, payment_id => Id}),
    %% enter new state with provided data
    {ok, state_new, Init}.
