all() -> [happy_path, over_capture].
