MsgTag({authorize,_}) -> authorize;
MsgTag({capture,_})   -> capture;
MsgTag({void})        -> void;
MsgTag({settle})      -> settle.
