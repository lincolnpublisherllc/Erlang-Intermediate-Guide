%% producer.erl
handle_info({ask, N, From}, S=#st{queue=Q}) ->
    {Send, Q1} = take_n(Q, N),
    [From ! {events, self(), E} || E <- Send],
    {noreply, S#st{queue=Q1}}.
Consumers send {ask, K, Producer} after draining previous events. You can layer this with supervisors and metrics the same way.
