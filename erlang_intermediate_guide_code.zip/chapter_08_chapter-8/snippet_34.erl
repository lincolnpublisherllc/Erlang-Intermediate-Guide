%%% State: voided / settled (terminal)
