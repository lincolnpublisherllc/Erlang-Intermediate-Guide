init_per_suite(C) ->
    application:ensure_all_started(kernel), C.
end_per_suite(_C) -> ok.
