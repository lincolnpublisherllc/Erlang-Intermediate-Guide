state_captured(state_timeout, settle_timeout, Data) ->
    emit_metric(settle_auto, state_captured, Data),
    {next_state, state_settled, Data};
