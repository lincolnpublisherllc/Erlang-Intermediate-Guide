emit_metric(Event, State, Data) ->
    %% Replace with proper telemetry; keep lightweight in example
    logger:info("metric ~p state=~p id=~p", [Event, State, maps:get(id, Data)]).
