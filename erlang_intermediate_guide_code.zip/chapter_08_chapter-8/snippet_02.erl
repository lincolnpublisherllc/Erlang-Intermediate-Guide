A behaviour (e.g., gen_server, gen_statem) defining callbacks
