state_voided({call, _From}, {_Any, Ref, Client, _}, _Data) ->
    reply(Client, Ref, error, #{reason => already_voided}),
    keep_state_and_data;
state_voided(_T,_E,_D) -> keep_state_and_data.
