MsgPayload({authorize, M}) -> M;
MsgPayload({capture, M})   -> M;
MsgPayload({void})         -> #{};  % none
MsgPayload({settle})       -> #{}.
