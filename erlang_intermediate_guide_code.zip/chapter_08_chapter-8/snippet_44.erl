One supervisor per unit (payments supervisor)
A top supervisor for the app, possibly with a registry and HTTP adapter
