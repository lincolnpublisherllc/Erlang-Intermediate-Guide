init([]) ->
    {ok, {{simple_one_for_one, 5, 10}, []}}.
This lets you spawn a pay_fsm per payment id. simple_one_for_one is a good fit when you start many similar children.
