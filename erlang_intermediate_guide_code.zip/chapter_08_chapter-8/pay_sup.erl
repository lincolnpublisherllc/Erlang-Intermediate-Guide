%% Extracted from document — source marker: pay_sup.erl
-module(pay_sup).
-behaviour(supervisor).
-export([start_link/0, start_payment/1, init/1]).
