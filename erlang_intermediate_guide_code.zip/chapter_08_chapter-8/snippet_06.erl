-type state_data() ::
  #{ id        := binary()
   , amount    := non_neg_integer()
   , auth_id   => binary()
   , captured  => non_neg_integer()
   , meta      := map()
   }.
8.3.3 FSM implementation (gen_statem)
