over_capture(_C) ->
    {ok,_} = pay_sup:start_payment(#{id => <<"t2">>, meta => #{}}),
    {ok,_} = pay_fsm:call(<<"t2">>, {authorize, #{amount=>100, card=><<"x">>}}),
    {error, #{reason := over_capture}} =
        pay_fsm:call(<<"t2">>, {capture, #{amount=>200}}),
    ok.
