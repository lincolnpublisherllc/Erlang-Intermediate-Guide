-type state() :: state_new | state_authorized | state_captured | state_voided | state_settled.
-type data()  :: map().
-type event() :: {authorize, reference(), pid(), map()}
               | {capture,   reference(), pid(), map()}
               | {void,      reference(), pid()}
               | {settle,    reference(), pid()}
               | timeout.
