Unit-style checks
Use gen_statem:call/2 indirectly via your public call/2 wrapper, or test with direct messages if you want more control. Keep assertions on:
