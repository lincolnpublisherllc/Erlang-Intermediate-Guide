%% Synchronous send with correlation id
call(Id, Msg) ->
    Ref = make_ref(),
    Name = {?MODULE, Id},
    Name ! {MsgTag(Msg), Ref, self(), MsgPayload(Msg)},
    receive
      {ok,    Ref, Reply} -> {ok, Reply};
      {error, Ref, Why}   -> {error, Why}
    after 5000 -> timeout
    end.
