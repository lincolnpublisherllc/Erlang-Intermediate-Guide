This pattern scales beyond payments: any workflow with clear phases fits nicely into gen_statem.
