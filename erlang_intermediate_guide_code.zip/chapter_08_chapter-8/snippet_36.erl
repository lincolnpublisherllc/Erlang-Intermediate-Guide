state_settled({call, _From}, {_Any, Ref, Client, _}, _Data) ->
    reply(Client, Ref, error, #{reason => already_settled}),
    keep_state_and_data;
state_settled(_T,_E,_D) -> keep_state_and_data.
