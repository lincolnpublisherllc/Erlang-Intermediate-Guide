Always include a correlation id (Ref = make_ref()) when a reply is expected
