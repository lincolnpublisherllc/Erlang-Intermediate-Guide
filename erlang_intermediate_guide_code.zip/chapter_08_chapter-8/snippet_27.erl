state_authorized({call, _From}, {void, Ref, Client}, Data) ->
    emit_metric(void_manual, state_authorized, Data),
    reply(Client, Ref, ok, #{status => voided}),
    {next_state, state_voided, Data};
